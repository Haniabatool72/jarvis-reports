#!/usr/bin/env python3
"""Jarvis Reports - single-file reporting system (Python stdlib only; psutil optional).

Password      :  OFF by default. Optional: --set-password / --remove-password
Run dashboard :  python jarvis_reports.py            -> http://127.0.0.1:8765
AI chat       :  set env ANTHROPIC_API_KEY (optional JARVIS_CHAT_MODEL) -> "AI Chat" tab
Sample data   :  python jarvis_reports.py --demo
Run self-tests:  python jarvis_reports.py --test
Use in Jarvis :  from jarvis_reports import log_activity, upsert_task, track, start
    log_activity("open chrome", "launched browser", "success")
    log_activity("weather", "api call", "error", "ConnectionError: ...")
    upsert_task("t1", "Send email", "pending")      # later: "completed" / "failed"
    @track("play music")                            # auto-logs success / error
    start(background=True)                          # dashboard inside Jarvis
    reply = voice_command(recognized_text)          # "show report" -> opens dashboard; None if not a report command
Data is stored in jarvis_reports.db next to this file (override: env JARVIS_REPORT_DB).
Extras        : install_error_hook()  logs uncaught exceptions; logging.getLogger().addHandler(JarvisLogHandler())
                logs ERROR lines.  Env JARVIS_SNAPSHOT_DAYS (default 30) / JARVIS_ACTIVITY_DAYS (default 0 = keep
                forever) control automatic cleanup.  --host 0.0.0.0 requires a password; JARVIS_ALLOWED_HOSTS
                lists extra host names when you bind to one specific non-local address.
"""
import argparse, collections, contextlib, csv, functools, getpass, hashlib, hmac, http.client, io, itertools, json, logging, os, platform
import re, secrets, shutil, sqlite3, sys, tempfile, threading, time, unittest, urllib.error, urllib.request, webbrowser
from datetime import datetime, timedelta
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

DB_PATH = os.environ.get("JARVIS_REPORT_DB",
                         os.path.join(os.path.dirname(os.path.abspath(__file__)), "jarvis_reports.db"))


STATUSES = ("success", "failed", "error")
TASK_STATUSES = ("pending", "running", "completed", "failed")
KINDS = ("activities", "tasks", "system", "full")
def _env_int(name, default):
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


EXPORT_LIMIT = 50000   # max rows in a report/export (the screens page through data with "Load more")
MAX_PAGE = 5000
SNAPSHOT_KEEP_DAYS = _env_int("JARVIS_SNAPSHOT_DAYS", 30)   # automatic cleanup of the CPU/RAM history
ACTIVITY_KEEP_DAYS = _env_int("JARVIS_ACTIVITY_DAYS", 0)    # 0 = keep activities/tasks forever
SAMPLE_SECS = 60
LOOPBACK = ("127.0.0.1", "localhost", "::1")
CSP = ("default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self' data:; "
       "connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
AI_STATES = ("idle", "listening", "thinking", "speaking", "error")
_ai = {"state": "idle", "detail": ""}


def set_ai_state(state, detail=""):
    """Tell the dashboard what Jarvis is REALLY doing: idle/listening/thinking/speaking/error. Never raises."""
    if state in AI_STATES:
        _ai["state"], _ai["detail"] = state, str(detail)[:80]


_lock = threading.RLock()
_ready = False   # kept for backwards compatibility; the connection logic below tracks DB_PATH itself
_con = None
_con_path = None

SCHEMA = """
CREATE TABLE IF NOT EXISTS activities(id INTEGER PRIMARY KEY, ts TEXT NOT NULL, command TEXT, action TEXT,
  status TEXT NOT NULL, error TEXT, solution TEXT, uid TEXT UNIQUE);
CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, task_id TEXT UNIQUE, title TEXT, status TEXT,
  created_at TEXT, updated_at TEXT, error TEXT, solution TEXT);
CREATE TABLE IF NOT EXISTS snapshots(id INTEGER PRIMARY KEY, ts TEXT, cpu REAL, ram REAL, disk REAL,
  status TEXT, uid TEXT UNIQUE);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS saved_reports(id INTEGER PRIMARY KEY, kind TEXT, date_from TEXT, date_to TEXT,
  created_at TEXT, body TEXT, uid TEXT UNIQUE);
"""

SOLUTIONS = [
    (("timeout", "timed out"), "The operation took too long. Check your internet connection and retry."),
    (("connection", "network", "unreachable", "dns", "offline"), "Network problem. Check your internet/Wi-Fi and try again."),
    (("permission", "access is denied", "forbidden"), "Permission denied. Run with the required permissions or check file/app access."),
    (("not found", "no such file", "filenotfound"), "A file or app was not found. Verify the path/name and that it is installed."),
    (("api key", "unauthorized", "401", "invalid key", "quota"), "Authentication/quota issue. Check your API key and usage limits."),
    (("microphone", "audio", "speech", "pyaudio"), "Audio problem. Check microphone connection/permissions and audio drivers."),
    (("modulenotfound", "importerror", "no module"), "A Python package is missing. Install it with pip install <package>."),
    (("memory",), "Low memory. Close other applications and retry."),
]


def _has_key(e, k):
    if k.isdigit():  # "401" must not match "port 4010"
        return re.search(r"(?<!\d)%s(?!\d)" % k, e) is not None
    return k in e


def suggest_solution(error):
    e = (error or "").lower()
    for keys, text in SOLUTIONS:
        if any(_has_key(e, k) for k in keys):
            return text
    return "Retry the task. If it fails again, check the Jarvis logs/traceback for details."


def _now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _uid(*parts):
    return hashlib.sha1("|".join(str(p) for p in parts).encode("utf-8")).hexdigest()


def _connect():
    """One shared SQLite connection (WAL mode), re-opened when DB_PATH changes. Caller holds _lock."""
    global _con, _con_path, _ready
    if _con is not None and _con_path == DB_PATH:
        return _con
    if _con is not None:
        try:
            _con.close()
        except Exception:
            pass
        _con = None
    con = sqlite3.connect(DB_PATH, timeout=10, check_same_thread=False)
    try:
        con.row_factory = sqlite3.Row
        try:
            con.execute("PRAGMA journal_mode=WAL")
            con.execute("PRAGMA synchronous=NORMAL")
        except sqlite3.DatabaseError:
            pass
        con.executescript(SCHEMA)
    except Exception:
        con.close()
        raise
    _con, _con_path, _ready = con, DB_PATH, True
    return con


def _exec(sql, args=(), fetch=False):
    """Run one statement thread-safely; creates the schema on first use."""
    with _lock:
        con = _connect()
        try:
            cur = con.execute(sql, args)
            out = [dict(r) for r in cur.fetchall()] if fetch else cur.rowcount
            con.commit()
            return out
        except Exception:
            try:
                con.rollback()
            except Exception:
                pass
            raise


# ---------------------------------------------------------------- recording
def log_activity(command, action="", status="success", error=None, ts=None):
    """Record one command. Never raises. Returns True if stored, False if duplicate/failed.
    Live entries (no ts given) are always stored, even twice in the same second.
    Entries with an explicit ts are de-duplicated (identical ts+command+action+status+error), so re-importing is safe."""
    try:
        status = status if status in STATUSES else "error"
        live = ts is None
        ts = ts or _now()
        err = str(error) if error else None
        sol = suggest_solution(err) if (err and status != "success") else None
        uid = _uid(ts, command, action, status, err, secrets.token_hex(4) if live else "")
        return _exec("INSERT OR IGNORE INTO activities(ts,command,action,status,error,solution,uid) "
                     "VALUES(?,?,?,?,?,?,?)",
                     (ts, str(command)[:500], str(action)[:500], status, err, sol, uid)) == 1
    except Exception:
        return False


def upsert_task(task_id, title, status="pending", error=None):
    """Create or update a task by task_id (no duplicates). Never raises."""
    try:
        status = status if status in TASK_STATUSES else "pending"
        err = str(error) if error else None
        sol = suggest_solution(err) if status == "failed" else None
        now = _now()
        _exec("INSERT INTO tasks(task_id,title,status,created_at,updated_at,error,solution) VALUES(?,?,?,?,?,?,?) "
              "ON CONFLICT(task_id) DO UPDATE SET title=excluded.title,status=excluded.status,"
              "updated_at=excluded.updated_at,error=excluded.error,solution=excluded.solution",
              (str(task_id), str(title)[:500], status, now, now, err, sol))
        return True
    except Exception:
        return False


def track(command_name=None):
    """Decorator: logs success or error of a Jarvis command function, then re-raises errors."""
    def deco(fn):
        @functools.wraps(fn)
        def wrapper(*a, **k):
            name = command_name or fn.__name__
            try:
                result = fn(*a, **k)
                log_activity(name, fn.__name__, "success")
                return result
            except Exception as e:
                log_activity(name, fn.__name__, "error", f"{type(e).__name__}: {e}")
                raise
        return wrapper
    return deco


def install_error_hook():
    """Log uncaught exceptions (main thread and other threads) in the Activity list. Call once at startup."""
    prev, prev_t = sys.excepthook, threading.excepthook

    def hook(tp, val, tb):
        if not issubclass(tp, KeyboardInterrupt):
            log_activity("uncaught exception", "python", "error", f"{tp.__name__}: {val}")
        prev(tp, val, tb)

    def thook(args):
        if args.exc_type is not SystemExit:
            log_activity("uncaught exception (thread)", getattr(args.thread, "name", "thread"), "error",
                         f"{args.exc_type.__name__}: {args.exc_value}")
        prev_t(args)
    sys.excepthook, threading.excepthook = hook, thook


class JarvisLogHandler(logging.Handler):
    """logging.getLogger().addHandler(JarvisLogHandler()) -> every ERROR/CRITICAL log line appears in Activity."""

    def __init__(self, level=logging.ERROR):
        super().__init__(level)

    def emit(self, record):
        try:
            extra = f" ({record.exc_info[0].__name__})" if record.exc_info and record.exc_info[0] else ""
            log_activity(record.name, "log", "error", record.getMessage() + extra)
        except Exception:
            pass


# ---------------------------------------------------------------- system info
def _win_cpu():
    if platform.system() != "Windows":
        return None
    try:
        import ctypes
        from ctypes import wintypes

        def times():
            i, k, u = (wintypes.FILETIME() for _ in range(3))
            if not ctypes.windll.kernel32.GetSystemTimes(ctypes.byref(i), ctypes.byref(k), ctypes.byref(u)):
                raise OSError("GetSystemTimes failed")
            q = lambda f: (f.dwHighDateTime << 32) | f.dwLowDateTime
            return q(i), q(k), q(u)
        i1, k1, u1 = times(); time.sleep(0.2); i2, k2, u2 = times()
        total = (k2 - k1) + (u2 - u1)  # kernel time already includes idle time
        return round(max(0.0, min(100.0, (total - (i2 - i1)) / total * 100)), 1) if total else None
    except Exception:
        return None


def _win_ram():
    if platform.system() != "Windows":
        return None, None
    try:
        import ctypes

        class MS(ctypes.Structure):
            _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                        ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                        ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                        ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                        ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
        m = MS(); m.dwLength = ctypes.sizeof(MS)
        if not ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m)):
            return None, None
        return float(m.dwMemoryLoad), round(m.ullAvailPhys / 2**30, 2)
    except Exception:
        return None, None


def _mac_ram():
    if platform.system() != "Darwin":
        return None, None
    try:
        import subprocess
        total = int(subprocess.check_output(["sysctl", "-n", "hw.memsize"], timeout=3))
        out = subprocess.check_output(["vm_stat"], timeout=3).decode()
        ps = int(re.search(r"page size of (\d+)", out).group(1))
        pg = lambda n: int(re.search(n + r":\s+(\d+)", out).group(1))
        avail = (pg("Pages free") + pg("Pages inactive") + pg("Pages speculative")) * ps
        return round((total - avail) / total * 100, 1), round(avail / 2**30, 2)
    except Exception:
        return None, None


def _cpu():
    try:
        import psutil
        return float(psutil.cpu_percent(interval=0.2))
    except Exception:
        pass
    try:
        return round(min(100.0, os.getloadavg()[0] / (os.cpu_count() or 1) * 100), 1)
    except Exception:
        return _win_cpu()


def _ram():
    try:
        import psutil
        m = psutil.virtual_memory()
        return float(m.percent), round(m.available / 2**30, 2)
    except Exception:
        pass
    try:
        d = {}
        with open("/proc/meminfo") as fh:
            for ln in fh:
                k, v = ln.split(":", 1)
                d[k] = int(v.split()[0])
        return round((d["MemTotal"] - d["MemAvailable"]) / d["MemTotal"] * 100, 1), round(d["MemAvailable"] / 2**20, 2)
    except Exception:
        return _win_ram() if platform.system() == "Windows" else _mac_ram()


def _disk():
    try:
        u = shutil.disk_usage(os.path.abspath(os.sep))
        return round(u.used / u.total * 100, 1), round(u.free / 2**30, 2)
    except Exception:
        return None, None


def _tz():
    z = time.strftime("%z") or "+0000"
    return f"UTC{z[:3]}:{z[3:]}"


def _measure():
    """Current CPU/RAM/disk. Anything unavailable is None and listed in 'unavailable'."""
    cpu = _cpu(); ram, ram_free = _ram(); disk, disk_free = _disk()
    vals = {"cpu": cpu, "ram": ram, "disk": disk}
    known = [v for v in vals.values() if v is not None]
    status = "Unknown" if not known else ("Critical" if max(known) >= 90 else "Warning" if max(known) >= 75 else "Healthy")
    return {"ts": _now(), "cpu": cpu, "ram": ram, "ram_available_gb": ram_free, "disk": disk,
            "disk_free_gb": disk_free, "status": status,
            "unavailable": [k for k, v in vals.items() if v is None],
            "os": platform.system() + " " + platform.release(), "host": platform.node(), "tz": _tz()}


_sys_cache = [0.0, None]
_sys_lock = threading.Lock()


def system_status(max_age=0):
    """Current CPU/RAM/disk. max_age > 0 re-uses a reading that is at most that many seconds old."""
    with _sys_lock:
        if max_age and _sys_cache[1] is not None and time.time() - _sys_cache[0] < max_age:
            return dict(_sys_cache[1])
        s = _measure()
        _sys_cache[0], _sys_cache[1] = time.time(), s
        return dict(s)


def record_snapshot(max_age=5):
    """Save a snapshot (max one per minute, deduplicated) and return it."""
    s = system_status(max_age)
    try:
        _exec("INSERT OR IGNORE INTO snapshots(ts,cpu,ram,disk,status,uid) VALUES(?,?,?,?,?,?)",
              (s["ts"], s["cpu"], s["ram"], s["disk"], s["status"], _uid(s["ts"][:16])))
    except Exception:
        pass
    return s


def purge_old(days=None, activity_days=None):
    """Delete old rows. days -> CPU/RAM snapshots; activity_days -> activities and finished tasks.
    None/0 means 'leave that part alone'. Returns {table: rows_deleted}."""
    cut = lambda n: (datetime.now() - timedelta(days=int(n))).strftime("%Y-%m-%d %H:%M:%S")
    out = {}
    if days:
        out["snapshots"] = _exec("DELETE FROM snapshots WHERE ts < ?", (cut(days),))
    if activity_days:
        out["activities"] = _exec("DELETE FROM activities WHERE ts < ?", (cut(activity_days),))
        out["tasks"] = _exec("DELETE FROM tasks WHERE updated_at < ? AND status IN ('completed','failed')",
                             (cut(activity_days),))
    return out


_sampler_stop = threading.Event()
_sampler_thread = None


def _sampler_loop():
    last_purge = 0.0
    while not _sampler_stop.is_set():
        try:
            record_snapshot(max_age=0)
            if time.time() - last_purge > 3600:
                purge_old(SNAPSHOT_KEEP_DAYS, ACTIVITY_KEEP_DAYS)
                last_purge = time.time()
        except Exception:
            pass
        _sampler_stop.wait(SAMPLE_SECS)


def start_sampler():
    """Background thread: one CPU/RAM/disk snapshot per minute (also while nobody has the dashboard open)
    plus hourly cleanup of old data. Safe to call many times."""
    global _sampler_thread
    if _sampler_thread is None or not _sampler_thread.is_alive():
        _sampler_stop.clear()
        _sampler_thread = threading.Thread(target=_sampler_loop, daemon=True, name="jarvis-sampler")
        _sampler_thread.start()


# ---------------------------------------------------------------- queries# ---------------------------------------------------------------- queries
def _range(col, f, t):
    c, a = [], []
    for v, op, suffix in ((f, ">=", " 00:00:00"), (t, "<=", " 23:59:59")):
        if not v:
            continue
        try:
            datetime.strptime(v, "%Y-%m-%d")
        except ValueError:
            continue  # ignore malformed dates instead of crashing
        c.append(f"{col} {op} ?"); a.append(v + suffix)
    return c, a


def _where(c):
    return " WHERE " + " AND ".join(c) if c else ""


def query_activities(f=None, t=None, q=None, status=None, limit=1000, offset=0):
    c, a = _range("ts", f, t)
    if status in STATUSES:
        c.append("status=?"); a.append(status)
    if q:
        c.append("(command LIKE ? OR action LIKE ? OR error LIKE ?)"); a += [f"%{q}%"] * 3
    return _exec("SELECT ts,command,action,status,error,solution FROM activities" + _where(c) +
                 " ORDER BY ts DESC, id DESC LIMIT ? OFFSET ?", a + [int(limit), int(offset)], fetch=True)


def query_tasks(f=None, t=None, q=None, status=None, limit=1000, offset=0):
    c, a = _range("updated_at", f, t)
    if status in TASK_STATUSES:
        c.append("status=?"); a.append(status)
    if q:
        c.append("(title LIKE ? OR task_id LIKE ? OR error LIKE ?)"); a += [f"%{q}%"] * 3
    return _exec("SELECT task_id,title,status,created_at,updated_at,error,solution FROM tasks" + _where(c) +
                 " ORDER BY updated_at DESC, id DESC LIMIT ? OFFSET ?", a + [int(limit), int(offset)], fetch=True)


def query_snapshots(f=None, t=None, limit=500):
    c, a = _range("ts", f, t)
    return _exec("SELECT ts,cpu,ram,disk,status FROM snapshots" + _where(c) + " ORDER BY ts DESC LIMIT ?",
                 a + [int(limit)], fetch=True)


def _count(table, col, f, t):
    c, a = _range(col, f, t)  # table/col come from constants below, never from user input
    rows = _exec(f"SELECT status, COUNT(*) AS n FROM {table}" + _where(c) + " GROUP BY status", a, fetch=True)
    return {r["status"]: r["n"] for r in rows}


def stats(f=None, t=None):
    a, k = _count("activities", "ts", f, t), _count("tasks", "updated_at", f, t)
    total = sum(a.values())
    return {"activities": {"total": total, **{s: a.get(s, 0) for s in STATUSES},
                           "success_rate": round(a.get("success", 0) / total * 100, 1) if total else None},
            "tasks": {"total": sum(k.values()), **{s: k.get(s, 0) for s in TASK_STATUSES}}}


# ---------------------------------------------------------------- reports / export
_COLS = {"activities": ["ts", "command", "action", "status", "error", "solution"],
         "tasks": ["task_id", "title", "status", "created_at", "updated_at", "error", "solution"],
         "system": ["ts", "cpu", "ram", "disk", "status"]}


def _rows(kind, f, t, q=None, status=None, limit=None):
    limit = limit or EXPORT_LIMIT
    if kind == "activities":
        return query_activities(f, t, q, status, limit)
    if kind == "tasks":
        return query_tasks(f, t, q, status, limit)
    return query_snapshots(f, t, limit)


def build_report(kind="full", f=None, t=None, q=None, status=None, stamp=True):
    kind = kind if kind in KINDS else "full"
    L = [f"JARVIS REPORT - {kind.upper()}", "=" * 70]
    if stamp:
        L.append("Generated : " + _now())
    L.append(f"Period    : {f or 'beginning'} to {t or 'now'}")
    L.append(f"Timezone  : {_tz()} (all times are local to this computer)")
    if q or status:
        L.append(f"Filter    : status={status or 'any'}, search={q or '-'}  (the summary counts cover the whole period)")
    s = stats(f, t)
    if kind in ("activities", "full"):
        a = s["activities"]
        L += ["", "DAILY ACTIVITY", "-" * 70,
              f"Total: {a['total']}  Success: {a['success']}  Failed: {a['failed']}  Errors: {a['error']}  "
              f"Success rate: {a['success_rate'] if a['success_rate'] is not None else 'n/a'}%", ""]
        rows = _rows("activities", f, t, q, status) or []
        for r in rows:
            L.append(f"{r['ts']}  [{r['status'].upper():7}] {r['command']}" + (f"  ->  {r['action']}" if r['action'] else ""))
            if r["error"]:
                L += [f"    Error   : {r['error']}", f"    Solution: {r['solution']}"]
        if len(rows) >= EXPORT_LIMIT:
            L.append(f"(List cut after the newest {EXPORT_LIMIT} rows; the totals above are complete.)")
        if not a["total"]:
            L.append("No activity recorded for this period.")
    if kind in ("tasks", "full"):
        k = s["tasks"]
        L += ["", "TASKS", "-" * 70,
              f"Total: {k['total']}  Completed: {k['completed']}  Pending: {k['pending']}  "
              f"Running: {k['running']}  Failed: {k['failed']}", ""]
        rows = _rows("tasks", f, t, q, status) or []
        for r in rows:
            L.append(f"[{r['status'].upper():9}] {r['title']} (id {r['task_id']})  created {r['created_at']}  updated {r['updated_at']}")
            if r["error"] or r["status"] == "failed":
                L += [f"    Error   : {r['error'] or 'n/a'}", f"    Solution: {r['solution']}"]
        if len(rows) >= EXPORT_LIMIT:
            L.append(f"(List cut after the newest {EXPORT_LIMIT} rows; the totals above are complete.)")
        if not k["total"]:
            L.append("No tasks recorded for this period.")
    if kind in ("system", "full"):
        cur = system_status(); fmt = lambda v, u="%": "unavailable" if v is None else f"{v}{u}"
        L += ["", "SYSTEM STATUS", "-" * 70, f"Status : {cur['status']}   ({cur['os']})",
              f"CPU    : {fmt(cur['cpu'])}", f"RAM    : {fmt(cur['ram'])}  (available {fmt(cur['ram_available_gb'], ' GB')})",
              f"Disk   : {fmt(cur['disk'])}  (free {fmt(cur['disk_free_gb'], ' GB')})"]
        hist = query_snapshots(f, t, 20)
        if hist:
            L += ["", "Recent snapshots:"] + [f"  {r['ts']}  CPU {fmt(r['cpu'])}  RAM {fmt(r['ram'])}  Disk {fmt(r['disk'])}  {r['status']}" for r in hist]
    return "\n".join(L)


def _safe(v):
    """Neutralise spreadsheet formula injection in CSV cells."""
    return "'" + v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@") else v


def to_csv(kind="activities", f=None, t=None, q=None, status=None):
    kinds = list(_COLS) if kind == "full" else [kind if kind in _COLS else "activities"]
    buf = io.StringIO(); w = csv.writer(buf)
    for i, k in enumerate(kinds):
        if len(kinds) > 1:
            w.writerow([f"# {k}"])
        w.writerow(_COLS[k])
        for r in _rows(k, f, t, q, status) or []:
            w.writerow([_safe(r.get(c, "")) for c in _COLS[k]])
        if i < len(kinds) - 1:
            w.writerow([])
    return buf.getvalue()


def to_pdf(text):
    """Minimal dependency-free PDF (Courier). Non-Latin characters (Urdu, Hindi...) cannot be embedded without
    a font, so they are shown as '?' and a note at the top says so (TXT/CSV keep the full text)."""
    try:
        text.encode("latin-1")
    except UnicodeEncodeError:
        text = "NOTE: Urdu/Hindi/other non-Latin text cannot be shown in this PDF (it appears as '?'). Use TXT or CSV export for the full text.\n\n" + text
    lines = []
    for ln in text.split("\n"):
        lines += [ln[i:i + 105] for i in range(0, max(len(ln), 1), 105)]
    pages = [lines[i:i + 70] for i in range(0, len(lines), 70)] or [[]]
    esc = lambda s: s.encode("latin-1", "replace").decode("latin-1").replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
    kids = " ".join(f"{4 + 2 * i} 0 R" for i in range(len(pages)))
    objs = [b"<</Type/Catalog/Pages 2 0 R>>", f"<</Type/Pages/Kids[{kids}]/Count {len(pages)}>>".encode(),
            b"<</Type/Font/Subtype/Type1/BaseFont/Courier>>"]
    for i, pg in enumerate(pages):
        body = ("BT /F1 8 Tf 10 TL 40 800 Td\n" + "".join(f"({esc(l)}) '\n" for l in pg) + "ET").encode("latin-1")
        objs.append(f"<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]/Resources<</Font<</F1 3 0 R>>>>/Contents {5 + 2 * i} 0 R>>".encode())
        objs.append(b"<</Length %d>>\nstream\n" % len(body) + body + b"\nendstream")
    out, offs = bytearray(b"%PDF-1.4\n"), []
    for i, o in enumerate(objs, 1):
        offs.append(len(out)); out += b"%d 0 obj\n" % i + o + b"\nendobj\n"
    x = len(out)
    out += b"xref\n0 %d\n0000000000 65535 f \n" % (len(objs) + 1)
    for o in offs:
        out += b"%010d 00000 n \n" % o
    out += b"trailer\n<</Size %d/Root 1 0 R>>\nstartxref\n%d\n%%%%EOF" % (len(objs) + 1, x)
    return bytes(out)


def export(kind, fmt, f=None, t=None, q=None, status=None):
    """Return (bytes, mime, filename) for txt/csv/pdf. Raises ValueError on bad input."""
    kind = kind if kind in KINDS else "full"
    name = f"jarvis_{kind}_{datetime.now():%Y%m%d_%H%M%S}.{fmt}"
    if fmt == "csv":
        return to_csv(kind, f, t, q, status).encode("utf-8-sig"), "text/csv; charset=utf-8", name
    if fmt == "txt":
        return build_report(kind, f, t, q, status).encode("utf-8"), "text/plain; charset=utf-8", name
    if fmt == "pdf":
        return to_pdf(build_report(kind, f, t, q, status)), "application/pdf", name
    raise ValueError("format must be txt, csv or pdf")


def save_report(kind="full", f=None, t=None):
    """Persist a generated report. Identical content for the same period is not stored twice.
    Reports with live CPU/RAM numbers (system/full) count as identical when generated in the same minute.
    Returns (id, created_bool)."""
    kind = kind if kind in KINDS else "full"
    sig = build_report(kind, f, t, stamp=False)
    if kind in ("system", "full"):  # live numbers change on every call, so ignore them and use the minute instead
        sig = re.sub(r"\nSYSTEM STATUS.*", "", sig, flags=re.S) + _now()[:16]
    uid = _uid(kind, f, t, hashlib.sha1(sig.encode()).hexdigest())
    created = _exec("INSERT OR IGNORE INTO saved_reports(kind,date_from,date_to,created_at,body,uid) VALUES(?,?,?,?,?,?)",
                    (kind, f, t, _now(), build_report(kind, f, t), uid)) == 1
    row = _exec("SELECT id FROM saved_reports WHERE uid=?", (uid,), fetch=True)[0]
    return row["id"], created


def list_saved():
    return _exec("SELECT id,kind,date_from,date_to,created_at FROM saved_reports ORDER BY id DESC LIMIT 200", fetch=True)


def get_saved(rid):
    rows = _exec("SELECT * FROM saved_reports WHERE id=?", (int(rid),), fetch=True)
    return rows[0] if rows else None


def delete_saved(rid):
    """Delete one saved report. Returns the number of rows removed (0 or 1)."""
    return _exec("DELETE FROM saved_reports WHERE id=?", (int(rid),))


# ---------------------------------------------------------------- password / login
SESSION_TTL, MAX_FAILS, LOCK_SECS = 8 * 3600, 5, 60
_sessions, _fails, _auth_lock = {}, {}, threading.Lock()


PBKDF2_ITER = 600_000  # old hashes (200,000 iterations) still work and are upgraded at the next successful login


def _hash(pw, salt=None, iters=PBKDF2_ITER):
    salt = salt or os.urandom(16)
    return f"pbkdf2${iters}${salt.hex()}${hashlib.pbkdf2_hmac('sha256', pw.encode('utf-8'), salt, iters).hex()}"


def _store_hash(pw):
    _exec("INSERT INTO settings(key,value) VALUES('password',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
          (_hash(pw),))


def set_password(pw):
    """Store a salted PBKDF2 hash (never the password itself). Logs everyone out."""
    if not pw or len(pw) < 6:
        raise ValueError("Password must be at least 6 characters")
    _store_hash(pw)
    with _auth_lock:
        _sessions.clear()


def clear_password():
    """Turn the optional login off again."""
    _exec("DELETE FROM settings WHERE key='password'")
    with _auth_lock:
        _sessions.clear()


def has_password():
    if os.environ.get("JARVIS_REPORT_PASSWORD"):
        return True
    try:
        return bool(_exec("SELECT 1 FROM settings WHERE key='password'", fetch=True))
    except Exception:
        return False


def check_password(pw):
    env = os.environ.get("JARVIS_REPORT_PASSWORD")  # optional: password from environment instead of DB
    if env:
        return hmac.compare_digest(str(pw).encode(), env.encode())
    try:
        parts = _exec("SELECT value FROM settings WHERE key='password'", fetch=True)[0]["value"].split("$")
        legacy = len(parts) == 2  # old format: salt$hash with 200,000 iterations
        iters, salt_hex, stored = (200_000, *parts) if legacy else (int(parts[1]), parts[2], parts[3])
        calc = hashlib.pbkdf2_hmac("sha256", str(pw).encode("utf-8"), bytes.fromhex(salt_hex), iters).hex()
        ok = hmac.compare_digest(calc, stored)
        if ok and (legacy or iters < PBKDF2_ITER):
            _store_hash(str(pw))  # upgrade the stored hash without logging anybody out
        return ok
    except Exception:
        return False


def _new_session():
    tok = secrets.token_urlsafe(32)
    now = time.time()
    with _auth_lock:
        for k in [k for k, v in _sessions.items() if v <= now]:  # forget expired sessions
            del _sessions[k]
        _sessions[tok] = now + SESSION_TTL
    return tok


def _valid_session(tok):
    with _auth_lock:
        if _sessions.get(tok, 0) > time.time():
            return True
        _sessions.pop(tok, None)
        return False


def _locked(ip):
    with _auth_lock:
        return _fails.get(ip, (0, 0))[1] > time.time()


def _fail(ip):
    with _auth_lock:
        n = _fails.get(ip, (0, 0))[0] + 1
        _fails[ip] = (0, time.time() + LOCK_SECS) if n >= MAX_FAILS else (n, 0)


# ---------------------------------------------------------------- dashboard (HTML)
DASHBOARD_HTML = r"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Jarvis AI</title>
<style>
/* ---- design tokens ---- */
:root{--bg:#080B10;--bg2:#0D121A;--card:#111923;--ac:#00E5FF;--ac2:#168BFF;--tx:#F1F5F9;--mut:#94A3B8;--bd:#243140;--ok:#22C55E;--wr:#F59E0B;--er:#EF4444;--r:14px;color-scheme:dark}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(900px 500px at 75% -10%,#0b1c2a 0,var(--bg) 65%) fixed;color:var(--tx);font:14px/1.55 "Segoe UI",Inter,system-ui,sans-serif}
:focus-visible{outline:2px solid var(--ac);outline-offset:2px}
/* ---- layout ---- */
.app{display:grid;grid-template-columns:236px 1fr;min-height:100vh;transition:grid-template-columns .25s}.app.min{grid-template-columns:68px 1fr}
aside{background:rgba(13,18,26,.92);border-inline-end:1px solid var(--bd);padding:16px 12px;display:flex;flex-direction:column;gap:16px;position:sticky;top:0;height:100vh;overflow:hidden}
.brand{display:flex;align-items:center;gap:10px;font-weight:700;letter-spacing:.16em;font-size:13px;white-space:nowrap}
.brand i{flex:none;width:24px;height:24px;border-radius:50%;border:2px solid var(--ac);box-shadow:inset 0 0 10px rgba(0,229,255,.35)}
.min .lbl,.min .brand span{display:none}
.tabs{display:flex;flex-direction:column;gap:4px}
.tabs button{display:flex;gap:12px;align-items:center;width:100%;text-align:start;background:none;border:1px solid transparent;color:var(--mut);padding:9px 10px;border-radius:10px;min-height:40px;transition:.15s}
.tabs button:hover{color:var(--tx);background:var(--card)}.tabs button.on{color:var(--ac);background:var(--card);border-color:var(--bd)}.ic{width:20px;text-align:center}
.grow{flex:1}.main{padding:20px 24px;max-width:1240px;width:100%;min-width:0}
.top{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:16px}.top h1{margin:0;font-size:18px;font-weight:600;display:inline}
.menu{display:none}
/* ---- controls ---- */
input,select,button{font:inherit;padding:8px 11px;border:1px solid var(--bd);border-radius:10px;background:var(--bg2);color:var(--tx);min-height:38px}
button{cursor:pointer;transition:.15s}button:hover{border-color:var(--ac2)}button:active{transform:scale(.97)}
button.p{background:linear-gradient(135deg,var(--ac2),#0aa6c9);border-color:transparent;color:#03131c;font-weight:600}
.bar{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:12px;align-items:center}.sp{flex:1}
/* ---- cards / tables ---- */
.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:16px}
.card{background:rgba(17,25,35,.85);border:1px solid var(--bd);border-radius:var(--r);padding:14px;backdrop-filter:blur(8px)}
.card b{display:block;font-size:26px;font-weight:600}.card span{color:var(--mut);font-size:11px;text-transform:uppercase;letter-spacing:.08em}
.wrap{overflow-x:auto;background:rgba(17,25,35,.85);border:1px solid var(--bd);border-radius:var(--r)}
table{width:100%;border-collapse:collapse}th,td{padding:10px 14px;text-align:start;border-bottom:1px solid var(--bd);vertical-align:top}
th{color:var(--mut);font-size:11px;text-transform:uppercase;letter-spacing:.08em;font-weight:600}tr:last-child td{border:0}tbody tr:hover{background:rgba(22,139,255,.06)}
.b{padding:2px 9px;border-radius:99px;font-size:12px;font-weight:600;border:1px solid currentColor;background:transparent}
.success,.completed,.Healthy{color:var(--ok)}.failed,.error,.Critical{color:var(--er)}.pending,.running,.Warning{color:var(--wr)}.Unknown{color:var(--mut)}
.sol{color:var(--mut);font-size:12px}.err{color:var(--er);font-size:12px}
pre{white-space:pre-wrap;background:var(--bg2);border:1px solid var(--bd);border-radius:var(--r);padding:14px;overflow-x:auto;color:var(--tx)}
.meter{height:6px;background:var(--bd);border-radius:6px;overflow:hidden;margin-top:8px}.meter i{display:block;height:100%;background:linear-gradient(90deg,var(--ac2),var(--ac))}
#msg{color:var(--er);margin:8px 0}
/* ---- AI core ---- */
.core{display:flex;align-items:center;gap:18px;padding:14px 18px;margin-bottom:16px;border:1px solid var(--bd);border-radius:var(--r);background:linear-gradient(135deg,rgba(0,229,255,.06),rgba(17,25,35,.85) 60%)}
.core svg{flex:none;overflow:visible}.core circle{fill:none;stroke:var(--ac);stroke-width:1.2}
.r3{opacity:.25}.r2{opacity:.5;transform-origin:60px 60px;animation:spin 30s linear infinite}.r1{opacity:.8}
.nuc{fill:var(--ac)!important;stroke:none!important;opacity:.9;transform-origin:60px 60px;animation:pulse 3.2s ease-in-out infinite}
.orbit{transform-origin:60px 60px;animation:spin 18s linear infinite}.orb{fill:var(--ac2)!important;stroke:none!important}
.st{font-size:18px;font-weight:700;letter-spacing:.16em}.dt{color:var(--mut)}
.wave{display:flex;gap:3px;align-items:flex-end;height:18px;margin-top:6px}.wave i{width:3px;height:4px;background:var(--ac);border-radius:2px}
[data-state=listening] .wave i,[data-state=speaking] .wave i{animation:eq .9s ease-in-out infinite}[data-state=speaking] .wave i{animation-duration:.55s}
.wave i:nth-child(2){animation-delay:.12s!important}.wave i:nth-child(3){animation-delay:.24s!important}.wave i:nth-child(4){animation-delay:.1s!important}.wave i:nth-child(5){animation-delay:.3s!important}
[data-state=thinking] .orbit{animation-duration:1.6s}[data-state=thinking] .r2{animation-duration:6s}[data-state=listening] .nuc{animation-duration:1.2s}
.core[data-state=error]{border-color:var(--er)}[data-state=error] .nuc,[data-state=error] .orb{fill:var(--er)!important}
@keyframes spin{to{transform:rotate(360deg)}}@keyframes pulse{50%{transform:scale(1.25);opacity:1}}@keyframes eq{50%{height:18px}}
@media(prefers-reduced-motion:reduce){*{animation:none!important;transition:none!important}}
/* ---- chat ---- */
body[data-tab=chat] .cards,body[data-tab=chat] .bar{display:none}
body[data-tab=chat] .core{padding:8px 16px;margin-bottom:12px}body[data-tab=chat] .core svg{width:56px;height:56px}
.chat{display:flex;flex-direction:column;gap:10px;height:calc(100dvh - 215px);min-height:360px}
.msgs{flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:14px;padding:4px 2px}
.m{display:flex;flex-direction:column;max-width:min(760px,92%);animation:fade .2s}.m.u{align-self:flex-end;align-items:flex-end}
.mb{padding:10px 14px;border-radius:16px;border:1px solid var(--bd);background:rgba(17,25,35,.85);overflow-wrap:anywhere;max-width:100%}
.u .mb{background:linear-gradient(135deg,rgba(22,139,255,.22),rgba(0,229,255,.08));border-color:rgba(22,139,255,.5)}.e .mb{border-color:var(--er)}
.mt{color:var(--mut);font-size:11px;margin-top:4px}.mt button,.ch button{min-height:0;padding:1px 8px;font-size:11px;border-radius:6px;background:none}
.typing{display:flex;gap:5px;align-items:center;color:var(--mut)}.typing i{width:6px;height:6px;border-radius:50%;background:var(--ac);animation:blink 1.2s infinite}
.typing i:nth-child(2){animation-delay:.2s}.typing i:nth-child(3){animation-delay:.4s}.typing span{margin-left:4px;font-size:12px}
.code{margin:8px 0;border:1px solid var(--bd);border-radius:10px;overflow:hidden;background:var(--bg)}
.ch{display:flex;justify-content:space-between;align-items:center;padding:4px 10px;background:var(--bg2);color:var(--mut);font-size:11px}
.code pre{margin:0;border:0;border-radius:0;background:none;font:12.5px/1.5 ui-monospace,Consolas,monospace;white-space:pre}
.code i{font-style:normal}.code .c{color:#64748b}.code .s{color:#7dd3fc}.code .k{color:var(--ac)}.code .n{color:var(--wr)}
.mb code{background:var(--bg2);padding:1px 5px;border-radius:5px;font-size:12.5px}.code code{background:none;padding:0;font-size:inherit}
.comp{display:flex;gap:8px;align-items:flex-end;padding:8px;border:1px solid var(--bd);border-radius:20px;background:rgba(13,18,26,.95)}.comp:focus-within{border-color:var(--ac2)}
.comp textarea{flex:1;resize:none;border:0;background:none;outline:0;max-height:160px;min-height:38px;padding:8px 10px;font:inherit;color:var(--tx)}.comp button{border-radius:14px;min-width:80px}
button:disabled,textarea:disabled{opacity:.5;cursor:not-allowed}
.hello{margin:auto;text-align:center}.hello h2{font-weight:600;font-size:22px;margin:0 0 14px}.sg{display:flex;flex-wrap:wrap;gap:8px;justify-content:center}.sg button{border-radius:99px}
#toasts{position:fixed;inset-inline-end:16px;bottom:16px;display:grid;gap:8px;z-index:50}.toast{padding:10px 14px;border-radius:10px;background:var(--card);border:1px solid var(--bd);animation:fade .2s}.toast.ok{border-color:var(--ok)}.toast.bad{border-color:var(--er)}
@keyframes fade{from{opacity:0;transform:translateY(4px)}}@keyframes blink{50%{opacity:.25}}
/* ---- languages / RTL ---- */
#lang{min-height:34px;padding:4px 8px}.code{direction:ltr;text-align:left}html[lang=ur] body{line-height:1.85}
@media(max-width:800px){[dir=rtl] aside{left:auto;right:0;transform:translateX(100%)}[dir=rtl] .app.open aside{transform:none}}
/* ---- responsive ---- */
@media(max-width:800px){.app,.app.min{grid-template-columns:1fr}.main{padding:14px}
aside{position:fixed;left:0;top:0;width:236px;z-index:20;transform:translateX(-100%);transition:transform .25s}.app.open aside{transform:none}
.min .lbl,.min .brand span{display:inline}.menu{display:inline-flex}#tg{display:none}.core svg{width:72px;height:72px}.bar input,.bar select{flex:1 1 130px}}
</style></head><body>
<div class="app" id="app">
<aside id="side"><div class="brand"><i></i><span>JARVIS AI</span></div>
<nav class="tabs" id="tabs" aria-label="Sections"></nav><div class="grow"></div>
<button id="tg" onclick="app.classList.toggle('min')" aria-label="Collapse or expand sidebar"><span class="ic">⇔</span><span class="lbl">Collapse</span></button></aside>
<div class="main">
<div class="top"><span><button class="menu" onclick="app.classList.toggle('open')" aria-label="Open menu">☰</button> <h1>AI Chat</h1></span>
<span><select id="lang" aria-label="Language"></select> <span id="sys" class="b">…</span> <button onclick="logout()">Logout</button></span></div>
<div class="core" id="core" data-state="idle" role="status" aria-live="polite">
<svg viewBox="0 0 120 120" width="96" height="96" aria-hidden="true"><circle class="r3" cx="60" cy="60" r="56"/><circle class="r2" cx="60" cy="60" r="44" stroke-dasharray="5 9"/><circle class="r1" cx="60" cy="60" r="30"/><circle class="nuc" cx="60" cy="60" r="14"/><g class="orbit"><circle class="orb" cx="60" cy="4" r="3.5"/></g></svg>
<div><div class="st"><span id="stIcon" aria-hidden="true">●</span> <span id="stName">IDLE</span></div><div class="dt" id="stDetail">Ready for commands</div><div class="wave" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></div></div></div>
<div class="cards" id="cards"></div>
<div class="bar">
 <label>From <input type="date" id="from"></label><label>To <input type="date" id="to"></label>
 <input id="q" placeholder="Search…" aria-label="Search"><select id="status" aria-label="Status"></select>
 <button class="p" onclick="lim=200;load()">Apply</button><button onclick="reset()">Reset</button><span class="sp"></span>
 <select id="fmt" aria-label="Export format"><option value="txt">TXT</option><option value="csv">CSV</option><option value="pdf">PDF</option></select>
 <button onclick="exp()">⬇ Export</button>
</div>
<div id="msg" role="alert"></div><div id="view"></div>
</div></div>
<div id="toasts" aria-live="polite"></div>
<script>
const $=s=>document.querySelector(s);
const esc=s=>String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const TABS={chat:"AI Chat",activities:"Activity",tasks:"Tasks",system:"System",saved:"Saved reports"};
const ST={chat:[],activities:["success","failed","error"],tasks:["pending","running","completed","failed"],system:[],saved:[]};
let tab="chat",lim=200;const app=$("#app"),IC={chat:"✦",activities:"▤",tasks:"☑",system:"◎",saved:"❒"};
const AIUI={idle:["●","IDLE","Ready for commands"],listening:["◉","LISTENING","Microphone is active"],thinking:["◌","THINKING","Processing"],speaking:["≋","SPEAKING","Voice output is active"],error:["⚠","ERROR","An operation failed"]};
async function pollAI(){try{const r=await fetch("/api/ai-state");if(!r.ok)return;const a=await r.json(),u=AIUI[a.state]||AIUI.idle;
 $("#core").dataset.state=a.state;$("#stIcon").textContent=u[0];$("#stName").textContent=u[1];$("#stDetail").textContent=a.detail||u[2]}catch(e){}}
setInterval(pollAI,1500);pollAI();
const pct=v=>v==null?"N/A":v+"%";
const qs=(all=true)=>{const p=new URLSearchParams();for(const k of ["from","to"])if($("#"+k).value)p.set(k,$("#"+k).value);
 if(all){if($("#q").value)p.set("q",$("#q").value);if($("#status").value)p.set("status",$("#status").value);p.set("limit",lim)}return p};
async function logout(){await fetch('/api/logout',{method:'POST',body:'{}'});try{localStorage.removeItem('jarvis_chat')}catch(e){}location.reload()}
async function api(u,o){const r=await fetch(u,o);if(r.status===401){location.reload();throw new Error('Login required')}const j=await r.json().catch(()=>({}));if(!r.ok)throw new Error(j.error||r.statusText);return j}
const badge=s=>`<span class="b ${esc(s)}">${esc(s)}</span>`;
const table=(h,rows)=>`<div class="wrap"><table><thead><tr>${h.map(x=>`<th>${x}</th>`).join("")}</tr></thead><tbody>${rows.length?rows.join(""):`<tr><td colspan="${h.length}">No records found.</td></tr>`}</tbody></table></div>`;
function tabs(){$("#tabs").innerHTML=Object.entries(TABS).map(([k,v])=>`<button class="${k==tab?"on":""}" onclick="setTab('${k}')" aria-label="${v}"${k==tab?' aria-current="page"':''}><span class="ic" aria-hidden="true">${IC[k]}</span><span class="lbl">${v}</span></button>`).join("");
 $("#status").innerHTML='<option value="">All statuses</option>'+ST[tab].map(s=>`<option value="${s}">${s}</option>`).join("");
 $("#status").style.display=ST[tab].length?"":"none";$("#q").style.display=(tab=="activities"||tab=="tasks")?"":"none";$("h1").textContent=TABS[tab];document.body.dataset.tab=tab}
function setTab(t){tab=t;lim=200;tabs();load();app.classList.remove('open')}
function reset(){["from","to","q","status"].forEach(k=>$("#"+k).value="");lim=200;load()}
function exp(){const p=qs();p.set("kind",tab=="saved"?"full":tab);p.set("format",$("#fmt").value);location.href="/api/export?"+p}
async function cards(){const s=await api("/api/stats?"+qs(false)),a=s.activities,t=s.tasks,y=s.system;
 const c=[["Commands",a.total],["Successful",a.success],["Failed",a.failed],["Errors",a.error],["Success rate",pct(a.success_rate)],
  ["Tasks done",t.completed],["Pending",t.pending+t.running],["Failed tasks",t.failed],["CPU",pct(y.cpu)],["RAM",pct(y.ram)],["Disk",pct(y.disk)]];
 $("#cards").innerHTML=c.map(([l,v])=>`<div class="card"><span>${l}</span><b>${esc(v)}</b></div>`).join("");
 $("#sys").className="b "+y.status;$("#sys").textContent="System: "+y.status;$("#sys").title="Times shown: "+(y.tz||"local")}
const more=d=>d.length>=lim?`<div class="bar"><button data-act="more">Load more</button></div>`:"";
const purgeBar=()=>`<div class="bar"><span class="sp"></span><button data-act="purge">🗑 Delete old data…</button></div>`;
const chart=h=>{const r=h.slice().reverse().filter(x=>x.cpu!=null||x.ram!=null||x.disk!=null);if(r.length<2)return"";
 const W=600,H=150,x=i=>(i/(r.length-1)*W).toFixed(1),y=v=>(H-v/100*H).toFixed(1);
 const ln=(k,c)=>{const pts=r.map((p,i)=>p[k]==null?null:x(i)+","+y(p[k])).filter(Boolean);return pts.length>1?`<polyline fill="none" stroke="${c}" stroke-width="1.8" points="${pts.join(" ")}"/>`:""};
 return `<div class="card" style="margin-bottom:12px"><span>History ${esc(r[0].ts)} → ${esc(r[r.length-1].ts)}</span><svg viewBox="0 0 ${W} ${H}" width="100%" height="150" preserveAspectRatio="none" role="img" aria-label="CPU, RAM and disk history, 0 to 100 percent">${[25,50,75].map(g=>`<line x1="0" x2="${W}" y1="${y(g)}" y2="${y(g)}" stroke="var(--bd)" stroke-dasharray="3 5"/>`).join("")}${ln("cpu","var(--ac)")}${ln("ram","var(--wr)")}${ln("disk","var(--ok)")}</svg><div class="sol"><span style="color:var(--ac)">━</span> CPU &nbsp; <span style="color:var(--wr)">━</span> RAM &nbsp; <span style="color:var(--ok)">━</span> Disk</div></div>`};
async function load(){$("#msg").textContent="";try{if(tab=="chat")return chatView();await cards();
 if(tab=="activities"){const d=await api("/api/activities?"+qs());
  $("#view").innerHTML=table(["Time","Command","Action","Status","Details"],d.map(r=>`<tr><td>${esc(r.ts)}</td><td class="ud">${esc(r.command)}</td><td class="ud">${esc(r.action)}</td><td>${badge(r.status)}</td><td>${r.error?`<div class="err ud">${esc(r.error)}</div><div class="sol">💡 ${esc(r.solution)}</div>`:""}</td></tr>`))+more(d)+purgeBar()}
 else if(tab=="tasks"){const d=await api("/api/tasks?"+qs());
  $("#view").innerHTML=table(["Task","Status","Created","Updated","Details"],d.map(r=>`<tr><td class="ud">${esc(r.title)}<div class="sol">${esc(r.task_id)}</div></td><td>${badge(r.status)}</td><td>${esc(r.created_at)}</td><td>${esc(r.updated_at)}</td><td>${r.status=="failed"?`<div class="err ud">${esc(r.error||"n/a")}</div><div class="sol">💡 ${esc(r.solution)}</div>`:""}</td></tr>`))+more(d)+purgeBar()}
 else if(tab=="system"){const d=await api("/api/system?"+qs(false)),l=d.live;
  const m=(n,v,x)=>`<div class="card"><span>${n}</span><b>${pct(v)}</b>${v==null?'<div class="sol">Not available on this system</div>':`<div class="meter"><i style="width:${v}%"></i></div>`}${x?`<div class="sol">${x}</div>`:""}</div>`;
  $("#view").innerHTML=`<div class="cards">${m("CPU",l.cpu)}${m("RAM",l.ram,l.ram_available_gb!=null?l.ram_available_gb+" GB available":"")}${m("Disk",l.disk,l.disk_free_gb!=null?l.disk_free_gb+" GB free":"")}</div>`+chart(d.history)+
   table(["Time","CPU","RAM","Disk","Status"],d.history.map(r=>`<tr><td>${esc(r.ts)}</td><td>${pct(r.cpu)}</td><td>${pct(r.ram)}</td><td>${pct(r.disk)}</td><td>${badge(r.status)}</td></tr>`))+purgeBar()}
 else{const d=await api("/api/saved");
  $("#view").innerHTML=`<div class="bar"><select id="k"><option value="full">Full</option><option value="activities">Activities</option><option value="tasks">Tasks</option><option value="system">System</option></select><button class="p" onclick="save()">Generate &amp; save report</button></div>`+
   table(["#","Type","Period","Created",""],d.map(r=>`<tr><td>${r.id}</td><td>${esc(r.kind)}</td><td>${esc(r.date_from||"start")} → ${esc(r.date_to||"now")}</td><td>${esc(r.created_at)}</td><td><button onclick="view(${r.id})">View</button> <button onclick="del(${r.id})">Delete</button></td></tr>`))+`<div id="rep"></div>`}
}catch(e){$("#msg").textContent="⚠ "+e.message}}
async function del(id){if(!confirm("Delete this saved report?"))return;try{await api("/api/saved/delete",{method:"POST",body:JSON.stringify({id})});load()}catch(e){$("#msg").textContent="⚠ "+e.message}}
async function purge(){const d=parseInt(prompt("Delete activities, finished tasks and CPU/RAM history older than how many days? (minimum 1)","90"),10);
 if(!(d>=1))return;if(!confirm("Permanently delete everything older than "+d+" days?"))return;
 try{const r=await api("/api/purge",{method:"POST",body:JSON.stringify({days:d})});toast("Deleted "+Object.values(r.deleted).reduce((a,b)=>a+b,0)+" rows","ok");load()}catch(e){toast(e.message,"bad")}}
async function save(){try{const r=await api("/api/saved",{method:"POST",body:JSON.stringify({kind:$("#k").value,from:$("#from").value,to:$("#to").value})});
 await load();$("#msg").style.color="var(--ok)";$("#msg").textContent=r.created?"Report saved.":"An identical report already exists (not duplicated).";setTimeout(()=>{$("#msg").style.color=""},50)}catch(e){$("#msg").textContent="⚠ "+e.message}}
async function view(id){try{const r=await api("/api/saved/"+id);$("#rep").innerHTML="<pre>"+esc(r.body)+"</pre>"}catch(e){$("#msg").textContent="⚠ "+e.message}}
/* ---- AI chat ---- */
const HK="jarvis_chat";let hist=[],busy=false;try{hist=JSON.parse(localStorage.getItem(HK)||"[]").filter(m=>m&&typeof m.content=="string"&&(m.role=="user"||m.role=="assistant"))}catch(e){}
const saveHist=()=>{try{localStorage.setItem(HK,JSON.stringify(hist.filter(m=>!m.err).slice(-50)))}catch(e){}};
const SUG=["Help me plan my day","Explain a concept simply","Write a Python function"];
const hm=()=>new Date().toLocaleTimeString([],{hour:"2-digit",minute:"2-digit"});
function toast(m,t){const d=document.createElement("div");d.className="toast "+(t||"");d.textContent=m;$("#toasts").append(d);setTimeout(()=>d.remove(),4000)}
const KW=/(#.*|\/\/.*)|("(?:[^"\\\n]|\\.)*"?|'(?:[^'\\\n]|\\.)*'?)|\b(def|class|return|if|else|elif|for|while|import|from|const|let|var|function|async|await|try|except|catch|in|not|and|or|None|True|False|true|false|null)\b|\b(\d+)\b/g;
function hl(c){let o="",last=0,m;KW.lastIndex=0;while((m=KW.exec(c))){o+=esc(c.slice(last,m.index))+`<i class="${m[1]?"c":m[2]?"s":m[3]?"k":"n"}">${esc(m[0])}</i>`;last=KW.lastIndex}return o+esc(c.slice(last))}
function md(t){const p=String(t??"").split(/```(\w*)\n?([\s\S]*?)```/);let o="";
 for(let i=0;i<p.length;i+=3){o+=esc(i?p[i].replace(/^\n/,""):p[i]).replace(/`([^`\n]+)`/g,"<code>$1</code>").replace(/\*\*([^*\n]+)\*\*/g,"<b>$1</b>").replace(/\n/g,"<br>");
  if(i+2<p.length)o+=`<div class="code"><div class="ch"><span>${esc(p[i+1]||"code")}</span><button data-copy>Copy code</button></div><pre><code>${hl(p[i+2].replace(/\n$/,""))}</code></pre></div>`}return o}
const bub=(m,i,last)=>{const u=m.role=="user";return `<div class="m ${u?"u":m.err?"e":"a"}"><div class="mb" dir="auto">${md(m.content)}</div><div class="mt"><span>${u?"You":"Jarvis"}</span> · ${m.ts}${u?"":m.err?` · <button data-act="regen">Retry</button>`:` · <button data-act="copy" data-i="${i}">Copy</button>${last?` <button data-act="regen">Regenerate</button>`:""}`}</div></div>`};
function paint(){const el=$("#msgs");if(!el)return;
 el.innerHTML=hist.length?hist.map((m,i)=>bub(m,i,i==hist.length-1&&!busy)).join(""):`<div class="hello"><h2>How can I help?</h2><div class="sg">${SUG.map(s=>`<button data-act="sug">${s}</button>`).join("")}</div></div>`;
 if(busy&&(!hist.length||hist[hist.length-1].role=="user"))el.insertAdjacentHTML("beforeend",`<div class="m a"><div class="mb typing" role="status" aria-label="Jarvis is thinking"><i></i><i></i><i></i><span>Thinking…</span></div></div>`);
 el.scrollTop=el.scrollHeight}
function busyUI(){const t=$("#in"),g=$("#go");if(!t)return;t.disabled=g.disabled=busy;g.textContent=busy?"Sending…":"Send";g.setAttribute("aria-busy",busy)}
function chatView(){$("#view").innerHTML=`<div class="chat"><div class="msgs" id="msgs" role="log" aria-live="polite" aria-label="Conversation"></div>
 <div class="comp"><textarea id="in" dir="auto" rows="1" placeholder="Message Jarvis…" aria-label="Message"></textarea><button class="p" id="go" data-act="send">Send</button></div>
 <div class="sol">Enter to send · Shift+Enter for a new line · / to focus · <button data-act="new">New chat</button></div></div>`;
 cards().catch(()=>{});paint();const t=$("#in");t.oninput=()=>{t.style.height="auto";t.style.height=Math.min(t.scrollHeight,160)+"px"};
 t.onkeydown=e=>{if(e.key=="Enter"&&!e.shiftKey&&!e.isComposing){e.preventDefault();send()}};busyUI();if(!busy)t.focus()}
function send(txt){if(busy)return;const t=$("#in");txt=(txt??t.value).trim();if(!txt)return;hist.push({role:"user",content:txt,ts:hm()});t.value="";t.style.height="auto";run()}
let pp=0;const schedulePaint=()=>{if(!pp)pp=requestAnimationFrame(()=>{pp=0;paint()})};
async function run(){busy=true;saveHist();paint();busyUI();const iv=setInterval(pollAI,400);let m=null;
 try{const sent=hist.filter(x=>!x.err).slice(-20).map(({role,content})=>({role,content:content.slice(0,8000)}));
  let tot=0;const keep=[];for(let i=sent.length-1;i>=0;i--){tot+=sent[i].content.length;if(tot>60000&&keep.length)break;keep.unshift(sent[i])}
  const r=await fetch("/api/chat-stream",{method:"POST",body:JSON.stringify({messages:keep,lang})});
  if(r.status==401){location.reload();return}
  if(!r.ok){const j=await r.json().catch(()=>({}));throw new Error(j.error||r.statusText)}
  const rd=r.body.getReader(),dec=new TextDecoder();let buf="",err=null;
  for(;;){const {done,value}=await rd.read();if(done)break;buf+=dec.decode(value,{stream:true});
   let nl;while((nl=buf.indexOf("\n"))>=0){const ln=buf.slice(0,nl).trim();buf=buf.slice(nl+1);if(!ln)continue;
    let o;try{o=JSON.parse(ln)}catch(e){continue}
    if(o.error)err=o.error;else if(o.t){if(!m){m={role:"assistant",content:"",ts:hm()};hist.push(m)}m.content+=o.t;schedulePaint()}}}
  if(err)throw new Error(err);
  if(!m)throw new Error("The AI returned an empty answer.")}
 catch(e){toast(e.message,"bad");hist.push({role:"assistant",content:"⚠ "+e.message,ts:hm(),err:1})}
 clearInterval(iv);busy=false;saveHist();paint();busyUI();$("#in")?.focus();pollAI()}
const cp=t=>navigator.clipboard.writeText(t).then(()=>toast("Copied","ok"),()=>toast("Copy failed","bad"));
$("#view").addEventListener("click",e=>{const b=e.target.closest("[data-act],[data-copy]");if(!b)return;
 if(b.dataset.copy!==undefined)return cp(b.closest(".code").querySelector("pre").textContent);
 const a=b.dataset.act;if(a=="copy")cp(hist[b.dataset.i].content);
 else if(a=="regen"&&!busy){while(hist.length&&hist[hist.length-1].role!="user")hist.pop();run()}
 else if(a=="send")send();else if(a=="sug")send(b.textContent);else if(a=="more"){lim+=200;load()}else if(a=="purge")purge();else if(a=="new"&&!busy){hist=[];saveHist();paint()}});
document.addEventListener("keydown",e=>{if(e.key=="/"&&tab=="chat"&&!/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)){e.preventDefault();$("#in")?.focus()}});
/* ---- languages: English / اردو / हिन्दी (add a row to ROWS to translate a new string) ---- */
const LANGS={en:"English",ur:"اردو",hi:"हिन्दी"},I18N={ur:{},hi:{}},SKIP=".mb,pre,script,style,textarea,#lang,.ud",memo=new WeakMap();
const ROWS=[
["AI Chat","اے آئی چیٹ","एआई चैट"],["Activity","سرگرمی","गतिविधि"],["Tasks","کام","कार्य"],["System","سسٹم","सिस्टम"],["Saved reports","محفوظ شدہ رپورٹس","सहेजी गई रिपोर्ट"],
["Collapse","سمیٹیں","छोटा करें"],["Logout","لاگ آؤٹ","लॉग आउट"],["Language","زبان","भाषा"],["Sections","حصے","अनुभाग"],["Open menu","مینو کھولیں","मेनू खोलें"],
["Collapse or expand sidebar","سائیڈ بار سمیٹیں یا کھولیں","साइडबार छोटा या बड़ा करें"],
["IDLE","فارغ","निष्क्रिय"],["LISTENING","سن رہا ہے","सुन रहा है"],["THINKING","سوچ رہا ہے","सोच रहा है"],["SPEAKING","بول رہا ہے","बोल रहा है"],["ERROR","خرابی","त्रुटि"],
["Ready for commands","احکامات کے لیے تیار","आदेशों के लिए तैयार"],["Microphone is active","مائیکروفون فعال ہے","माइक्रोफ़ोन चालू है"],["Processing","پروسیسنگ جاری ہے","प्रोसेस हो रहा है"],
["Voice output is active","آواز کا آؤٹ پٹ فعال ہے","आवाज़ आउटपुट चालू है"],["An operation failed","ایک عمل ناکام ہوا","एक ऑपरेशन विफल हुआ"],
["Answering your message","آپ کے پیغام کا جواب دے رہا ہے","आपके संदेश का उत्तर दे रहा है"],
["Commands","کمانڈز","कमांड"],["Successful","کامیاب","सफल"],["Failed","ناکام","विफल"],["Errors","خرابیاں","त्रुटियाँ"],["Success rate","کامیابی کی شرح","सफलता दर"],
["Tasks done","مکمل کام","पूरे हुए कार्य"],["Pending","زیر التوا","लंबित"],["Failed tasks","ناکام کام","विफल कार्य"],["Disk","ڈسک","डिस्क"],
["System: Healthy","سسٹم: صحت مند","सिस्टम: स्वस्थ"],["System: Warning","سسٹم: انتباہ","सिस्टम: चेतावनी"],["System: Critical","سسٹم: نازک","सिस्टम: गंभीर"],["System: Unknown","سسٹم: نامعلوم","सिस्टम: अज्ञात"],
["From","از","से"],["To","تک","तक"],["Apply","لاگو کریں","लागू करें"],["Reset","ری سیٹ","रीसेट"],["⬇ Export","⬇ ایکسپورٹ","⬇ निर्यात"],["Search…","تلاش…","खोजें…"],["Search","تلاش","खोजें"],
["All statuses","تمام حالتیں","सभी स्थितियाँ"],["Export format","ایکسپورٹ فارمیٹ","निर्यात प्रारूप"],["Status","حالت","स्थिति"],
["success","کامیاب","सफल"],["failed","ناکام","विफल"],["error","خرابی","त्रुटि"],["pending","زیر التوا","लंबित"],["running","جاری","चल रहा है"],["completed","مکمل","पूर्ण"],
["Time","وقت","समय"],["Command","کمانڈ","कमांड"],["Action","عمل","क्रिया"],["Details","تفصیلات","विवरण"],["Task","کام","कार्य"],["Created","تخلیق","बनाया गया"],["Updated","اپ ڈیٹ","अपडेट"],
["Type","قسم","प्रकार"],["Period","مدت","अवधि"],["View","دیکھیں","देखें"],["Full","مکمل","पूरा"],["Activities","سرگرمیاں","गतिविधियाँ"],
["No records found.","کوئی ریکارڈ نہیں ملا۔","कोई रिकॉर्ड नहीं मिला।"],["Generate & save report","رپورٹ بنائیں اور محفوظ کریں","रिपोर्ट बनाएँ और सहेजें"],
["Not available on this system","اس سسٹم پر دستیاب نہیں","इस सिस्टम पर उपलब्ध नहीं"],
["How can I help?","میں آپ کی کیسے مدد کر سکتا ہوں؟","मैं आपकी कैसे मदद कर सकता हूँ?"],["Help me plan my day","میرا دن پلان کرنے میں مدد کریں","मेरा दिन प्लान करने में मदद करें"],
["Explain a concept simply","ایک تصور آسان الفاظ میں سمجھائیں","कोई अवधारणा सरल शब्दों में समझाएँ"],["Write a Python function","ایک Python فنکشن لکھیں","एक Python फ़ंक्शन लिखें"],
["Send","بھیجیں","भेजें"],["Sending…","بھیجا جا رہا ہے…","भेजा जा रहा है…"],["Thinking…","سوچ رہا ہے…","सोच रहा है…"],["Copy","کاپی","कॉपी"],["Copy code","کوڈ کاپی کریں","कोड कॉपी करें"],
["Regenerate","دوبارہ بنائیں","फिर से बनाएँ"],["Retry","دوبارہ کوشش","दोबारा कोशिश"],["New chat","نئی چیٹ","नई चैट"],["You","آپ","आप"],
["Message Jarvis…","جاروس کو پیغام لکھیں…","जार्विस को संदेश लिखें…"],["Message","پیغام","संदेश"],["Conversation","گفتگو","बातचीत"],["Jarvis is thinking","جاروس سوچ رہا ہے","जार्विस सोच रहा है"],
["Copied","کاپی ہو گیا","कॉपी हो गया"],["Copy failed","کاپی ناکام","कॉपी विफल"],["Load more","مزید دکھائیں","और दिखाएँ"],["🗑 Delete old data…","🗑 پرانا ڈیٹا حذف کریں…","🗑 पुराना डेटा हटाएँ…"],["Delete","حذف کریں","हटाएँ"],
["Enter to send · Shift+Enter for a new line · / to focus ·","بھیجنے کے لیے Enter · نئی لائن کے لیے Shift+Enter · فوکس کے لیے / ·","भेजने के लिए Enter · नई पंक्ति के लिए Shift+Enter · फ़ोकस के लिए / ·"]];
for(const [k,u,h] of ROWS){I18N.ur[k]=u;I18N.hi[k]=h}
let lang="en";try{lang=LANGS[localStorage.getItem("jarvis_lang")]?localStorage.getItem("jarvis_lang"):"en"}catch(e){}
function sw(o,k,get,set){const D=I18N[lang]||{};let m=memo.get(o);if(!m)memo.set(o,m={});let e=m[k];const cur=get();
 if(!e||cur!==e.t)e=m[k]={o:cur,t:cur};const key=e.o.trim(),tx=D[key]?e.o.replace(key,D[key]):e.o;if(tx!==cur)set(tx);e.t=tx}
function applyLang(){const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT),L=[];let n;while(n=w.nextNode())L.push(n);
 for(const n of L)if(n.nodeValue.trim()&&(!n.parentElement.closest(SKIP)||n.parentElement.closest(".ch")))sw(n,"v",()=>n.nodeValue,v=>n.nodeValue=v);
 document.querySelectorAll("[placeholder],[aria-label]").forEach(el=>{if(!el.closest(".mb"))for(const a of ["placeholder","aria-label"])if(el.hasAttribute(a))sw(el,a,()=>el.getAttribute(a),v=>el.setAttribute(a,v))})}
function setLang(l){lang=l;try{localStorage.setItem("jarvis_lang",l)}catch(e){}const h=document.documentElement;h.lang=l;h.dir=l=="ur"?"rtl":"ltr";$("#lang").value=l;applyLang()}
let trPend=false;new MutationObserver(()=>{if(lang=="en"||trPend)return;trPend=true;requestAnimationFrame(()=>{trPend=false;applyLang()})}).observe(document.body,{childList:true,subtree:true,characterData:true});
$("#lang").innerHTML=Object.entries(LANGS).map(([k,v])=>`<option value="${k}">${v}</option>`).join("");$("#lang").onchange=e=>setLang(e.target.value);
tabs();load();setInterval(()=>{if(!document.hidden&&(tab=="system"||tab=="activities"||tab=="tasks")&&!document.activeElement.matches("input,select"))load()},15000);setLang(lang);
</script></body></html>
"""

LOGIN_HTML = r"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Jarvis - Login</title>
<style>
:root{--bg:#080B10;--card:#111923;--tx:#F1F5F9;--bd:#243140;--ac:#00E5FF;--er:#EF4444;color-scheme:dark}
body{margin:0;min-height:100vh;display:grid;place-items:center;background:var(--bg);color:var(--tx);font:15px system-ui,Segoe UI,sans-serif}
form{background:var(--card);border:1px solid var(--bd);border-radius:14px;padding:28px;width:min(340px,90vw);display:grid;gap:12px}
h1{margin:0;font-size:20px}input,button{font:inherit;padding:10px;border-radius:8px;border:1px solid var(--bd);background:var(--card);color:var(--tx)}
button{background:var(--ac);color:#04121a;font-weight:600;border-color:var(--ac);cursor:pointer}#m{color:var(--er);min-height:1.2em;font-size:13px}
</style></head><body>
<form id="f"><h1>🔒 Jarvis Reports</h1>
<input type="password" id="p" placeholder="Password" autocomplete="current-password" autofocus required>
<button type="submit">Login</button><div id="m"></div></form>
<script>
document.getElementById("f").onsubmit=async e=>{e.preventDefault();const m=document.getElementById("m");m.textContent="";
try{const r=await fetch("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:document.getElementById("p").value})});
const j=await r.json().catch(()=>({}));if(r.ok)location.reload();else m.textContent=j.error||"Login failed"}catch(x){m.textContent="Server not reachable"}};
</script></body></html>"""


# ---------------------------------------------------------------- web server
class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json", headers=None):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        if ctype.startswith("text/html"):
            self.send_header("Content-Security-Policy", CSP)
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200, headers=None):
        self._send(code, json.dumps(obj).encode("utf-8"), "application/json", headers)

    def _token(self):
        try:
            c = SimpleCookie(self.headers.get("Cookie", ""))
            return c["jarvis_session"].value if "jarvis_session" in c else None
        except Exception:
            return None

    def _authed(self):
        if not has_password():  # no password configured -> open (127.0.0.1 only)
            return True
        tok = self._token()
        return bool(tok) and _valid_session(tok)

    def _host_ok(self):
        """Reject requests whose Host header is not ours (blocks DNS-rebinding attacks from other websites)."""
        allowed = getattr(self.server, "allowed_hosts", None)
        return allowed is None or _host_name(self.headers.get("Host")) in allowed

    def do_GET(self):
        try:
            if not self._host_ok():
                return self._json({"error": "Bad host"}, 403)
            u = urlparse(self.path)
            p = u.path
            if p == "/":  # login page unless logged in
                page = DASHBOARD_HTML if self._authed() else LOGIN_HTML
                if page is DASHBOARD_HTML and not has_password():  # nothing to log out of
                    page = page.replace('<button onclick="logout()">Logout</button>', "")
                return self._send(200, page.encode("utf-8"), "text/html; charset=utf-8", {"Cache-Control": "no-store"})
            if not self._authed():
                return self._json({"error": "Login required"}, 401)
            q = {k: v[0] for k, v in parse_qs(u.query).items()}
            f, t, s, text = q.get("from"), q.get("to"), q.get("status"), q.get("q")
            lim = max(1, min(int(q.get("limit", 1000)), MAX_PAGE))
            off = max(0, int(q.get("offset", 0)))
            if p == "/api/stats":
                d = stats(f, t); d["system"] = record_snapshot(); self._json(d)
            elif p == "/api/activities":
                self._json(query_activities(f, t, text, s, lim, off))
            elif p == "/api/tasks":
                self._json(query_tasks(f, t, text, s, lim, off))
            elif p == "/api/system":
                self._json({"live": record_snapshot(), "history": query_snapshots(f, t, 300)})
            elif p == "/api/ai-state":
                self._json(dict(_ai))
            elif p == "/api/saved":
                self._json(list_saved())
            elif p.startswith("/api/saved/"):
                r = get_saved(p.rsplit("/", 1)[1])
                self._json(r, 200) if r else self._json({"error": "Report not found"}, 404)
            elif p == "/api/export":
                data, mime, name = export(q.get("kind", "full"), q.get("format", "txt"), f, t, text, s)
                self._send(200, data, mime, {"Content-Disposition": f'attachment; filename="{name}"'})
            else:
                self._json({"error": "Not found"}, 404)
        except ValueError as e:
            self._json({"error": str(e)}, 400)
        except Exception as e:
            self._json({"error": f"Server error: {type(e).__name__}"}, 500)

    def _chat(self, b):
        if not _chat_rate_ok():
            return self._json({"error": "Too many chat requests. Wait a minute and try again."}, 429)
        ms = b.get("messages")
        n = _last_len(ms)
        _chat_begin()
        try:
            text = chat_reply(ms, lang=b.get("lang"))
        except ChatError as e:
            if e.code == 400:
                _chat_end()
            else:
                _chat_end(str(e)); log_activity("AI chat message", "ai chat", "error", str(e))
            return self._json({"error": str(e)}, e.code)
        except Exception as e:  # never leave the core stuck on THINKING
            msg = f"Unexpected error: {type(e).__name__}"
            _chat_end(msg); log_activity("AI chat message", "ai chat", "error", msg)
            return self._json({"error": msg}, 500)
        _chat_end(); log_activity(f"AI chat message ({n} chars)", "ai chat", "success")  # the text itself is NOT stored
        self._json({"reply": text})

    def _ndjson(self, obj):
        self.wfile.write(json.dumps(obj).encode("utf-8") + b"\n")
        self.wfile.flush()

    def _chat_stream(self, b):
        """Like _chat, but sends the answer piece by piece as lines of JSON: {"t": text} ... {"done": true}."""
        if not _chat_rate_ok():
            return self._json({"error": "Too many chat requests. Wait a minute and try again."}, 429)
        ms = b.get("messages")
        lang = b.get("lang")
        lang = LANG_NAMES.get(lang, "") if isinstance(lang, str) else ""
        n = _last_len(ms)
        _chat_begin()
        started, err, code = False, None, 500
        try:
            it = iter(_chat_llm_stream(_prep_msgs(ms), lang))
            first = next(it, None)  # key / rate-limit / network problems surface here, before anything is sent
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.end_headers()
            started = True
            got = ""
            for piece in (it if first is None else itertools.chain([first], it)):
                got += piece
                self._ndjson({"t": piece})
            if not got.strip():
                raise ChatError("The AI returned an empty answer.")
            self._ndjson({"done": True})
        except (BrokenPipeError, ConnectionResetError):  # the browser closed the page
            _chat_end()
            return
        except ChatError as e:
            err, code = str(e), e.code
        except Exception as e:
            err, code = f"Unexpected error: {type(e).__name__}", 500
        else:
            _chat_end(); log_activity(f"AI chat message ({n} chars)", "ai chat", "success")
            return
        if code == 400 and not started:
            _chat_end()
        else:
            _chat_end(err); log_activity("AI chat message", "ai chat", "error", err)
        if started:
            try:
                self._ndjson({"error": err})
            except OSError:
                pass
        else:
            self._json({"error": err}, code)

    def do_POST(self):
        try:
            if not self._host_ok():
                return self._json({"error": "Bad host"}, 403)
            p = urlparse(self.path).path
            o = self.headers.get("Origin")  # block cross-site POSTs
            if o and urlparse(o).netloc != self.headers.get("Host"):
                return self._json({"error": "Bad origin"}, 403)
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                return self._json({"error": "Bad Content-Length"}, 400)
            if n < 0 or n > 1_000_000:
                return self._json({"error": "Request too large"}, 413)
            try:
                b = json.loads(self.rfile.read(n) or b"{}")
                if not isinstance(b, dict):
                    raise ValueError("JSON body must be an object")
            except ValueError:
                return self._json({"error": "Invalid JSON body"}, 400)
            if p == "/api/login":
                ip = self.client_address[0]
                if _locked(ip):
                    return self._json({"error": f"Too many attempts. Try again in {LOCK_SECS} seconds."}, 429)
                if check_password(b.get("password", "")):
                    with _auth_lock:
                        _fails.pop(ip, None)
                    ck = f"jarvis_session={_new_session()}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_TTL}"
                    return self._json({"ok": True}, 200, {"Set-Cookie": ck})
                _fail(ip)
                return self._json({"error": "Wrong password"}, 401)
            if p == "/api/logout":
                with _auth_lock:
                    _sessions.pop(self._token(), None)
                return self._json({"ok": True}, 200, {"Set-Cookie": "jarvis_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0"})
            if not self._authed():
                return self._json({"error": "Login required"}, 401)
            if p == "/api/chat":
                return self._chat(b)
            if p == "/api/chat-stream":
                return self._chat_stream(b)
            if p == "/api/saved":
                rid, created = save_report(b.get("kind", "full"), b.get("from") or None, b.get("to") or None)
                return self._json({"id": rid, "created": created})
            if p == "/api/saved/delete":
                try:
                    rid = int(b.get("id"))
                except (TypeError, ValueError):
                    return self._json({"error": "id is required"}, 400)
                return self._json({"deleted": delete_saved(rid)})
            if p == "/api/purge":
                try:
                    days = int(b.get("days"))
                except (TypeError, ValueError):
                    return self._json({"error": "days is required"}, 400)
                if days < 1:
                    return self._json({"error": "days must be at least 1"}, 400)
                return self._json({"deleted": purge_old(days, days)})
            return self._json({"error": "Not found"}, 404)
        except ValueError as e:
            self._json({"error": str(e)}, 400)
        except Exception as e:
            self._json({"error": f"Server error: {type(e).__name__}"}, 500)


def _host_name(h):
    """'localhost:8765' -> 'localhost', '[::1]:8765' -> '::1'."""
    h = (h or "").strip().lower()
    if h.startswith("["):
        return h[1:h.find("]")] if "]" in h else h
    return h.rsplit(":", 1)[0] if h.count(":") == 1 else h


def start(host="127.0.0.1", port=8765, background=False, sampler=True):
    if host not in LOOPBACK and not has_password():
        raise RuntimeError(f"Refusing to listen on {host or 'all interfaces'} without a password. "
                           "Run with --set-password first, or use the default 127.0.0.1.")
    srv = ThreadingHTTPServer((host, port), Handler)
    extra = {h.strip().lower() for h in os.environ.get("JARVIS_ALLOWED_HOSTS", "").split(",") if h.strip()}
    # wildcard bind: any Host is accepted because a password is mandatory then
    srv.allowed_hosts = None if host in ("0.0.0.0", "::", "") else {*LOOPBACK, host.lower(), *extra}
    if sampler:
        start_sampler()
    if background:
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        return srv
    print(f"Jarvis dashboard: http://{host}:{port}  (Ctrl+C to stop)")
    if not has_password():
        print("Note: no password set - anyone using THIS computer can open it. Optional: --set-password")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        srv.server_close()


CHAT_MODEL = os.environ.get("JARVIS_CHAT_MODEL", "claude-sonnet-5-5")
LANG_NAMES = {"en": "English", "ur": "Urdu", "hi": "Hindi"}
CHAT_SYSTEM = ("You are Jarvis, a capable, concise personal AI assistant. LANGUAGE RULE (most important): always reply in "
               "exactly the same language AND script as the user's LATEST message - English -> English, Urdu script -> Urdu script, "
               "Hindi (Devanagari) -> Hindi, Roman Urdu / Hinglish (Urdu or Hindi typed in English letters) -> Roman Urdu in English letters, "
               "any other language -> that language. Decide from the latest message only; ignore earlier messages and ignore any "
               "interface/display language. If the user switches language, switch with them immediately. If the message is only code or "
               "numbers, keep the language of the previous user message. Use fenced code blocks for code. Say so when you are unsure.")
RETRY_CODES = (429, 500, 502, 503, 529)   # temporary AI-service problems: retried twice before giving up
CHAT_RATE = (30, 60)                      # at most 30 chat requests per 60 s (protects your API credit)
_chat_hits = collections.deque()
_ai_lock = threading.Lock()
_ai_active = 0
_err_gen = [0]


class ChatError(Exception):
    def __init__(self, msg, code=502):
        super().__init__(msg); self.code = code


def _ai_error(detail):
    """Show ERROR on the core, then return to idle after 8 seconds (unless a newer error replaced it)."""
    set_ai_state("error", detail)
    _err_gen[0] += 1
    g = _err_gen[0]
    t = threading.Timer(8, lambda: _err_gen[0] == g and _ai["state"] == "error" and set_ai_state("idle"))
    t.daemon = True; t.start()


def _chat_rate_ok():
    n, per = CHAT_RATE
    now = time.time()
    with _ai_lock:
        while _chat_hits and _chat_hits[0] < now - per:
            _chat_hits.popleft()
        if len(_chat_hits) >= n:
            return False
        _chat_hits.append(now)
        return True


def _chat_begin():
    global _ai_active
    with _ai_lock:
        _ai_active += 1
    set_ai_state("thinking", "Answering your message")


def _chat_end(error=None):
    """Finish one chat request. error=str shows ERROR; otherwise back to idle once no other chat is running."""
    global _ai_active
    with _ai_lock:
        _ai_active = max(0, _ai_active - 1)
        busy = _ai_active > 0
    if error:
        _ai_error(error)
    elif not busy and _ai["state"] != "error":
        set_ai_state("idle")


def _last_len(ms):
    ms = ms if isinstance(ms, list) else []
    return next((len(str(m.get("content", ""))) for m in reversed(ms) if isinstance(m, dict) and m.get("role") == "user"), 0)


def _http_msg(code):
    return {401: "The AI service rejected the API key (401). Check ANTHROPIC_API_KEY.",
            403: "The AI service refused the request (403). Check your API key and account.",
            404: "The AI model was not found (404). Check JARVIS_CHAT_MODEL.",
            429: "The AI service is rate-limited right now (429). Wait a moment and try again.",
            529: "The AI service is overloaded (529). Try again shortly."}.get(
        code, f"AI service error {code}. Check your API key and credit.")


def _net_msg(e):
    return f"Network problem, could not reach the AI service ({getattr(e, 'reason', e) or type(e).__name__})."


def _chat_request(msgs, lang="", stream=False):
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        raise ChatError("No API key. Set the ANTHROPIC_API_KEY environment variable and restart Jarvis.", 503)
    payload = {"model": CHAT_MODEL, "max_tokens": 2048, "messages": msgs,
               "system": CHAT_SYSTEM}  # the reply language follows the user's message, never the dashboard's display language
    if stream:
        payload["stream"] = True
    return urllib.request.Request("https://api.anthropic.com/v1/messages", data=json.dumps(payload).encode("utf-8"), headers={
        "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})


def _open_with_retry(req):
    """Open the request; 429/5xx answers are retried twice (honouring Retry-After, max 10 s)."""
    for attempt in range(3):
        try:
            return urllib.request.urlopen(req, timeout=90)
        except urllib.error.HTTPError as e:
            if e.code in RETRY_CODES and attempt < 2:
                try:
                    wait = float(e.headers.get("retry-after"))
                except (TypeError, ValueError, AttributeError):
                    wait = 2.0 * (attempt + 1)
                time.sleep(min(max(wait, 0.5), 10))
                continue
            raise ChatError(_http_msg(e.code))
        except (OSError, http.client.HTTPException) as e:  # URLError, timeouts, dropped connections
            raise ChatError(_net_msg(e))


def _chat_llm(msgs, lang=""):
    resp = _open_with_retry(_chat_request(msgs, lang))
    try:
        with resp as r:
            data = json.load(r)
    except ValueError:
        raise ChatError("The AI service returned an unreadable answer.")
    except (OSError, http.client.HTTPException) as e:
        raise ChatError(_net_msg(e))
    return "".join(x.get("text", "") for x in data.get("content", []) if x.get("type") == "text")


def _chat_llm_stream(msgs, lang=""):
    """Generator of text pieces from the streaming API. Raises ChatError (also on the first next())."""
    resp = _open_with_retry(_chat_request(msgs, lang, stream=True))
    try:
        with resp as r:
            for raw in r:
                line = raw.decode("utf-8", "replace").strip()
                if not line.startswith("data:"):
                    continue
                try:
                    ev = json.loads(line[5:])
                except ValueError:
                    continue
                if ev.get("type") == "content_block_delta" and ev.get("delta", {}).get("type") == "text_delta":
                    yield ev["delta"].get("text", "")
                elif ev.get("type") == "error":
                    raise ChatError("AI service error: " + str((ev.get("error") or {}).get("message", "unknown")))
    except (OSError, http.client.HTTPException) as e:
        raise ChatError(_net_msg(e))


def _prep_msgs(messages):
    """Clean a client message list; raises ChatError(400) unless it ends with a user message."""
    if not isinstance(messages, list):
        messages = []
    msgs = [{"role": m["role"], "content": str(m.get("content", ""))[:8000]} for m in messages[-20:]
            if isinstance(m, dict) and m.get("role") in ("user", "assistant") and str(m.get("content", "")).strip()]
    while msgs and msgs[0]["role"] != "user":
        msgs.pop(0)
    if not msgs or msgs[-1]["role"] != "user":
        raise ChatError("Send a message first.", 400)
    return msgs


def chat_reply(messages, llm=None, lang=""):
    """messages: [{role: user|assistant, content}]. Returns the assistant reply or raises ChatError."""
    msgs = _prep_msgs(messages)
    text = (llm or _chat_llm)(msgs, LANG_NAMES.get(lang, "") if isinstance(lang, str) else "")
    if not text or not text.strip():
        raise ChatError("The AI returned an empty answer.")
    return text.strip()


_server = None
_REPORT_NOUN = re.compile(r"(?<!\w)(reports?|dashboard)(?!\w)|رپورٹ|ڈیش\s*بورڈ|रिपोर्ट|डैशबोर्ड", re.I)
_VERBS = {"show", "open", "display", "view", "launch", "see", "start", "dikhao", "dikha", "dikhana", "dikhaiye",
          "kholo", "khol", "kholiye", "دکھاؤ", "دکھا", "دکھائیں", "کھولو", "کھول", "کھولیں",
          "दिखाओ", "दिखा", "दिखाइए", "खोलो", "खोल", "खोलिए"}
_NOT_REPORT = {"weather", "news", "stock", "mausam", "موسم", "خبر", "خبریں", "मौसम", "खबर", "ख़बर"}  # "weather report" etc.
_FILLER = {"jarvis", "the", "my", "a", "please", "plz", "جاروس", "जार्विस"}


def is_report_command(text):
    """True for things like 'show report', 'open dashboard', 'report dikhao'; False for 'weather report batao'."""
    t = (text or "").lower()
    if not _REPORT_NOUN.search(t):
        return False
    toks = [x for x in re.split(r"[\s,.!?;:।؟،]+", t) if x]
    if any(x in _NOT_REPORT for x in toks):
        return False
    return any(x in _VERBS for x in toks) or len([x for x in toks if x not in _FILLER]) <= 2


def open_dashboard(port=8765, open_browser=True):
    """Start the dashboard server in the background (once) and open it in the browser."""
    global _server
    url = f"http://127.0.0.1:{port}"
    try:
        if _server is None:
            _server = start(port=port, background=True)
    except OSError:
        pass  # port already in use -> dashboard is probably already running
    if open_browser:
        webbrowser.open(url)
    return url


def voice_command(text):
    """Call with your recognized speech. If it is a report command, opens the dashboard and returns
    a reply you can speak; otherwise returns None so your normal command handling continues."""
    if not is_report_command(text):
        return None
    try:
        open_dashboard()
        log_activity(text, "open dashboard", "success")
        return "Opening your reports dashboard."
    except Exception as e:
        log_activity(text, "open dashboard", "error", f"{type(e).__name__}: {e}")
        return "Sorry, I could not open the dashboard."


def _prompt_password():
    while True:
        a = getpass.getpass("New dashboard password (min 6 characters): ")
        if a != getpass.getpass("Repeat password: "):
            print("Passwords do not match, try again."); continue
        try:
            set_password(a); print("Password saved."); return
        except ValueError as e:
            print(e)


def seed_demo():
    """Optional SAMPLE data so you can preview the dashboard. Only runs with --demo."""
    for c, a, s, e in [("open chrome", "launched browser", "success", None),
                       ("what is the weather", "weather lookup", "error", "ConnectionError: network unreachable"),
                       ("play music", "play_song", "failed", "FileNotFoundError: no such file"),
                       ("tell me a joke", "joke", "success", None)]:
        log_activity(c, a, s, e)
    upsert_task("demo-1", "Send email to team", "completed")
    upsert_task("demo-2", "Set reminder 5pm", "pending")
    upsert_task("demo-3", "Download report", "failed", "Connection timed out")




# ---------------------------------------------------------------- self-tests (python jarvis_reports.py --test)
core = sys.modules[__name__]
REAL_OPEN = urllib.request.urlopen  # the tests replace urllib.request.urlopen, the test client must not use the fake


class T(unittest.TestCase):
    """Every test gets its own empty database, so tests do not depend on each other or on their order."""
    PW = "test-pass-123"

    def setUp(self):
        core.DB_PATH = os.path.join(tempfile.mkdtemp(), "t.db"); core._ready = False
        for k in ("JARVIS_REPORT_PASSWORD", "ANTHROPIC_API_KEY"):
            os.environ.pop(k, None)
        core._fails.clear(); core._sessions.clear(); core._chat_hits.clear()
        core._sys_cache[:] = [0.0, None]; core._ai.update(state="idle", detail=""); core._ai_active = 0
        self._servers = []

    def tearDown(self):
        for srv in self._servers:
            srv.shutdown(); srv.server_close()
        os.environ.pop("ANTHROPIC_API_KEY", None)

    # ---- helpers
    def serve(self):
        srv = start(port=0, background=True, sampler=False); self._servers.append(srv)
        return f"http://127.0.0.1:{srv.server_address[1]}"

    def req(self, base, path, data=None, headers=None, opener=None):
        h = {"Content-Type": "application/json"}; h.update(headers or {})
        r = urllib.request.Request(base + path, data=None if data is None else json.dumps(data).encode(), headers=h)
        try:
            with (opener.open(r) if opener else REAL_OPEN(r)) as resp:
                return resp.status, resp.read()
        except urllib.error.HTTPError as e:
            return e.code, e.read()

    def seed(self):  # three known activities
        core.log_activity("open chrome", "x", "success", ts="2026-01-01 10:00:00")
        core.log_activity("weather", "w", "error", "Connection timed out", ts="2026-01-02 09:00:00")
        core.log_activity("=cmd()", "", "success", ts="2026-01-03 00:00:00")

    USER = [{"role": "user", "content": "hi"}]

    # ---- recording / queries
    def test_1_dedupe_and_status(self):
        self.assertTrue(core.log_activity("open chrome", "x", "success", ts="2026-01-01 10:00:00"))
        self.assertFalse(core.log_activity("open chrome", "x", "success", ts="2026-01-01 10:00:00"))  # explicit ts: deduped
        core.log_activity("weather", "w", "error", "Connection timed out", ts="2026-01-02 09:00:00")
        s = core.stats()["activities"]
        self.assertEqual((s["total"], s["success"], s["error"], s["success_rate"]), (2, 1, 1, 50.0))
        self.assertIn("internet", core.query_activities(status="error")[0]["solution"].lower())
        self.assertTrue(core.log_activity("ping")); self.assertTrue(core.log_activity("ping"))  # live entries are never dropped
        self.assertEqual(core.stats()["activities"]["total"], 4)

    def test_2_filters_and_paging(self):
        self.seed()
        self.assertEqual(len(core.query_activities("2026-01-02", "2026-01-02")), 1)
        self.assertEqual(len(core.query_activities(q="chrome")), 1)
        self.assertEqual(len(core.query_activities("garbage", "bad")), 3)  # bad dates ignored
        self.assertEqual(len(core.query_activities(limit=2)), 2)
        self.assertEqual(len(core.query_activities(limit=2, offset=2)), 1)

    def test_3_tasks_upsert(self):
        core.upsert_task("a", "Email", "pending"); core.upsert_task("a", "Email", "failed", "no such file")
        t = core.query_tasks(); self.assertEqual(len(t), 1); self.assertEqual(t[0]["status"], "failed")
        self.assertTrue(t[0]["solution"])
        k = core.stats()["tasks"]; self.assertEqual((k["total"], k["failed"], k["pending"]), (1, 1, 0))

    def test_3b_solution_matching(self):
        self.assertIn("Authentication", core.suggest_solution("HTTP 401 Unauthorized"))
        self.assertIn("Authentication", core.suggest_solution("error 401"))
        self.assertNotIn("Authentication", core.suggest_solution("listening on port 4010"))

    def test_4_system_graceful(self):
        orig = core._cpu, core._ram, core._disk
        core._cpu = lambda: None; core._ram = lambda: (None, None); core._disk = lambda: (None, None)
        try:
            s = core.system_status(); rep = core.build_report("system")
        finally:
            core._cpu, core._ram, core._disk = orig
        self.assertEqual(s["status"], "Unknown"); self.assertEqual(len(s["unavailable"]), 3)
        self.assertIn("unavailable", rep)
        self.assertEqual(core._win_ram(), (None, None)); self.assertIsNone(core._win_cpu())  # not Windows -> graceful
        core.record_snapshot(max_age=0); self.assertEqual(len(core.query_snapshots()), 1)

    # ---- reports / export
    def test_5_exports(self):
        self.seed()
        for fmt, magic in (("txt", b"JARVIS"), ("csv", b"\xef\xbb\xbf"), ("pdf", b"%PDF")):
            data, _, _ = core.export("full", fmt); self.assertTrue(data.startswith(magic), fmt)
        self.assertTrue(core.to_pdf("x" * 500 + "\n" * 200).count(b"/Type/Page/") >= 3)
        self.assertIn(b"non-Latin", core.to_pdf("رپورٹ"))  # Urdu -> the PDF says what happened
        with self.assertRaises(ValueError): core.export("full", "exe")
        self.assertIn("'=cmd()", core.to_csv("activities"))  # spreadsheet formula injection neutralised

    def test_5b_report_truncation_note(self):
        self.seed(); old = core.EXPORT_LIMIT; core.EXPORT_LIMIT = 2
        try:
            self.assertIn("List cut", core.build_report("activities"))
        finally:
            core.EXPORT_LIMIT = old
        self.assertNotIn("List cut", core.build_report("activities"))
        self.assertIn("Timezone", core.build_report("activities"))

    def test_6_saved_reports_dedupe_and_delete(self):
        self.seed()
        a = core.save_report("activities", "2026-01-01", "2026-01-02"); b = core.save_report("activities", "2026-01-01", "2026-01-02")
        self.assertEqual((a[1], b[1], a[0] == b[0]), (True, False, True))
        self.assertIn("JARVIS", core.get_saved(a[0])["body"])
        orig = core._now
        try:  # reports with live CPU/RAM numbers: same minute = same report
            core._now = lambda: "2026-05-05 10:00:00"
            c = core.save_report("full"); d = core.save_report("full")
            self.assertEqual((c[1], d[1], c[0] == d[0]), (True, False, True))
            core._now = lambda: "2026-05-05 10:01:00"
            self.assertTrue(core.save_report("full")[1])
        finally:
            core._now = orig
        self.assertEqual(core.delete_saved(a[0]), 1); self.assertIsNone(core.get_saved(a[0]))

    def test_6b_purge(self):
        core.log_activity("old", ts="2020-01-01 00:00:00"); core.log_activity("recent")
        self.assertEqual(core.purge_old(activity_days=30)["activities"], 1)
        self.assertEqual(core.stats()["activities"]["total"], 1)

    # ---- HTTP / login / security
    def test_7_http_and_login(self):
        self.seed(); core.set_password(self.PW)
        base = self.serve(); op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor())
        code = lambda path, data=None: self.req(base, path, data, opener=op)[0]
        self.assertNotIn(b'id="cards"', self.req(base, "/", opener=op)[1])  # login page, not the dashboard
        self.assertEqual(code("/api/stats"), 401)                           # data locked without login
        self.assertEqual(code("/api/export?format=txt"), 401)
        self.assertEqual(code("/api/login", {"password": "wrong"}), 401)
        self.assertEqual(code("/api/login", {"password": self.PW}), 200)
        self.assertIn(b'id="cards"', self.req(base, "/", opener=op)[1])     # dashboard after login
        self.assertEqual(json.loads(self.req(base, "/api/stats", opener=op)[1])["activities"]["total"], 3)
        self.assertEqual(len(json.loads(self.req(base, "/api/activities?limit=2", opener=op)[1])), 2)
        self.assertTrue(self.req(base, "/api/export?kind=tasks&format=pdf", opener=op)[1].startswith(b"%PDF"))
        self.assertEqual(code("/api/export?format=zip"), 400)
        self.assertEqual(code("/api/activities?limit=abc"), 400)
        code("/api/logout", {}); self.assertEqual(code("/api/stats"), 401)
        for _ in range(5): code("/api/login", {"password": "x"})
        self.assertEqual(code("/api/login", {"password": self.PW}), 429)  # locked out

    def test_7b_password_storage(self):
        core.set_password(self.PW)
        with self.assertRaises(ValueError): core.set_password("123")
        raw = core._exec("SELECT value FROM settings", fetch=True)[0]["value"]
        self.assertNotIn(self.PW, raw); self.assertTrue(raw.startswith("pbkdf2$600000$"))
        self.assertTrue(core.check_password(self.PW)); self.assertFalse(core.check_password("nope"))
        salt = os.urandom(16)  # an old-format (200,000 iterations) hash still works and is upgraded
        legacy = salt.hex() + "$" + hashlib.pbkdf2_hmac("sha256", b"old-pass-1", salt, 200_000).hex()
        core._exec("INSERT OR REPLACE INTO settings(key,value) VALUES('password',?)", (legacy,))
        self.assertTrue(core.check_password("old-pass-1"))
        self.assertTrue(core._exec("SELECT value FROM settings", fetch=True)[0]["value"].startswith("pbkdf2$600000$"))
        self.assertTrue(core.check_password("old-pass-1"))

    def test_7c_open_without_password(self):
        self.seed(); self.assertFalse(core.has_password())
        base = self.serve()
        page = self.req(base, "/")[1]
        self.assertIn(b'id="cards"', page); self.assertNotIn(b'onclick="logout()"', page)  # Logout hidden without a password
        self.assertEqual(json.loads(self.req(base, "/api/stats")[1])["activities"]["total"], 3)

    def test_7d_voice_command(self):
        for t in ("Jarvis show report", "open dashboard", "report", "mujhe report dikhao", "रिपोर्ट दिखाओ", "رپورٹ دکھاؤ"):
            self.assertTrue(core.is_report_command(t), t)
        for t in ("play music", "what is the weather", "", "weather report batao", "show weather report", "read the news report"):
            self.assertFalse(core.is_report_command(t), t)
        orig, core.open_dashboard = core.open_dashboard, (lambda *a, **k: "http://x")  # no real browser in tests
        try:
            self.assertIn("dashboard", core.voice_command("show report").lower())
            self.assertIsNone(core.voice_command("play music"))
        finally:
            core.open_dashboard = orig

    def test_7e_ai_state(self):
        core.set_ai_state("thinking", "Writing assignment"); core.set_ai_state("bogus", "x")  # invalid ignored
        d = json.loads(self.req(self.serve(), "/api/ai-state")[1])
        self.assertEqual((d["state"], d["detail"]), ("thinking", "Writing assignment"))

    def test_7f_chat(self):
        with self.assertRaises(core.ChatError): core.chat_reply([])
        with self.assertRaises(core.ChatError): core.chat_reply([{"role": "assistant", "content": "hi"}])
        seen = []
        out = core.chat_reply([{"role": "assistant", "content": "x"}, {"role": "user", "content": "hello"}],
                              llm=lambda m, l="": seen.append(m) or " Hi! ")
        self.assertEqual(out, "Hi!"); self.assertEqual(seen[0][0]["role"], "user")  # leading assistant turn dropped
        self.assertEqual(core.chat_reply(self.USER, llm=lambda m, l="": l, lang="ur"), "Urdu")
        self.assertEqual(core.chat_reply(self.USER, llm=lambda m, l="": l or "none", lang="zz"), "none")  # unknown language ignored
        base = self.serve()
        body = {"messages": self.USER}
        self.assertEqual(self.req(base, "/api/chat", body)[0], 503); self.assertEqual(core._ai["state"], "error")  # real failure -> ERROR
        self.assertEqual(self.req(base, "/api/chat", body, {"Origin": "http://evil.example"})[0], 403)  # cross-site POST blocked

    def test_7g_chat_failures(self):
        base = self.serve(); orig = core._chat_llm; os.environ["ANTHROPIC_API_KEY"] = "test-key"
        post = lambda msgs: self.req(base, "/api/chat", {"messages": msgs})[0]
        def reset(*a, **k): raise ConnectionResetError("reset")
        urllib.request.urlopen = reset  # connection dropped mid-request
        try: self.assertEqual(post(self.USER), 502)
        finally: urllib.request.urlopen = REAL_OPEN
        self.assertEqual(core._ai["state"], "error")  # shown as ERROR, not stuck on thinking
        def odd(m, l=""): raise KeyError("x")
        try:
            core._chat_llm = odd; core.set_ai_state("idle")
            self.assertEqual(post(self.USER), 500); self.assertEqual(core._ai["state"], "error")
            core._chat_llm = lambda m, l="": "ok"
            big = [{"role": "user", "content": "ا" * 8000} for _ in range(20)]  # long Urdu history (~1 MB of JSON escapes)
            self.assertEqual(post(big), 200)
        finally:
            core._chat_llm = orig
        # the chat text itself must never be stored in the activity log
        core._chat_llm = lambda m, l="": "ok"
        try: self.req(base, "/api/chat", {"messages": [{"role": "user", "content": "my secret thing"}]})
        finally: core._chat_llm = orig
        self.assertFalse(any("secret" in str(r) for r in core.query_activities()))

    def test_7h_host_and_headers(self):
        base = self.serve(); host = base.split("//")[1]
        c = http.client.HTTPConnection(host); c.request("GET", "/api/stats", headers={"Host": "evil.example"})
        self.assertEqual(c.getresponse().status, 403); c.close()  # DNS-rebinding style request
        c = http.client.HTTPConnection(host); c.request("GET", "/"); r = c.getresponse(); r.read()
        self.assertEqual(r.getheader("X-Frame-Options"), "DENY")
        self.assertIn("frame-ancestors 'none'", r.getheader("Content-Security-Policy")); c.close()
        c = http.client.HTTPConnection(host); c.request("POST", "/api/saved", body=b"{not json", headers={"Content-Type": "application/json"})
        self.assertEqual(c.getresponse().status, 400); c.close()
        with self.assertRaises(RuntimeError): start(host="0.0.0.0", port=0, background=True, sampler=False)  # no password -> refused
        core.set_password(self.PW)
        srv = start(host="0.0.0.0", port=0, background=True, sampler=False); self._servers.append(srv)
        c = http.client.HTTPConnection("127.0.0.1", srv.server_address[1]); c.request("GET", "/", headers={"Host": "mypc.lan"})
        self.assertEqual(c.getresponse().status, 200); c.close()  # wildcard bind + password: any host name is fine

    def test_7i_retry_and_messages(self):
        os.environ["ANTHROPIC_API_KEY"] = "k"; real_sleep = time.sleep; calls = []
        def flaky(req, timeout=None):
            calls.append(1)
            if len(calls) < 3: raise urllib.error.HTTPError("u", 429, "slow", {}, None)
            return io.BytesIO(b'{"content":[{"type":"text","text":"ok"}]}')
        urllib.request.urlopen = flaky; time.sleep = lambda s: None
        try:
            self.assertEqual(core._chat_llm(self.USER), "ok"); self.assertEqual(len(calls), 3)
            calls.clear()
            def busy(req, timeout=None): calls.append(1); raise urllib.error.HTTPError("u", 529, "busy", {}, None)
            urllib.request.urlopen = busy
            with self.assertRaises(core.ChatError) as c: core._chat_llm(self.USER)
            self.assertIn("overloaded", str(c.exception)); self.assertEqual(len(calls), 3)
            calls.clear()
            def bad(req, timeout=None): calls.append(1); raise urllib.error.HTTPError("u", 401, "no", {}, None)
            urllib.request.urlopen = bad  # not retried
            with self.assertRaises(core.ChatError) as c: core._chat_llm(self.USER)
            self.assertIn("API key", str(c.exception)); self.assertEqual(len(calls), 1)
        finally:
            urllib.request.urlopen = REAL_OPEN; time.sleep = real_sleep

    def test_7j_stream_parser(self):
        sse = (b'event: message_start\ndata: {"type":"message_start"}\n\n'
               b'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":"Hi"}}\n\n'
               b'data: {"type":"content_block_delta","delta":{"type":"text_delta","text":" there"}}\n\n')
        orig = core._open_with_retry; os.environ["ANTHROPIC_API_KEY"] = "k"
        try:
            core._open_with_retry = lambda req: io.BytesIO(sse)
            self.assertEqual(list(core._chat_llm_stream(self.USER)), ["Hi", " there"])
            core._open_with_retry = lambda req: io.BytesIO(b'data: {"type":"error","error":{"message":"overloaded"}}\n\n')
            with self.assertRaises(core.ChatError): list(core._chat_llm_stream(self.USER))
        finally:
            core._open_with_retry = orig

    def test_7k_chat_stream_http(self):
        base = self.serve(); body = {"messages": self.USER}; orig = core._chat_llm_stream
        lines = lambda raw: [json.loads(x) for x in raw.decode().split("\n") if x]
        self.assertEqual(self.req(base, "/api/chat-stream", body)[0], 503)  # no key: plain JSON error, nothing streamed
        try:
            core._chat_llm_stream = lambda m, l="": iter(["Hel", "lo"])
            st, raw = self.req(base, "/api/chat-stream", body)
            self.assertEqual(st, 200); self.assertEqual(lines(raw), [{"t": "Hel"}, {"t": "lo"}, {"done": True}])
            self.assertEqual(core._ai["state"], "idle")
            def bad(m, l=""):
                yield "a"
                raise core.ChatError("boom")
            core._chat_llm_stream = bad
            st, raw = self.req(base, "/api/chat-stream", body)
            self.assertIn({"error": "boom"}, lines(raw)); self.assertEqual(core._ai["state"], "error")
            self.assertEqual(self.req(base, "/api/chat-stream", {"messages": []})[0], 400)
        finally:
            core._chat_llm_stream = orig

    def test_7l_chat_rate_limit(self):
        base = self.serve(); orig, rate = core._chat_llm, core.CHAT_RATE
        core._chat_llm = lambda m, l="": "ok"; core.CHAT_RATE = (2, 60)
        try:
            self.assertEqual([self.req(base, "/api/chat", {"messages": self.USER})[0] for _ in range(3)], [200, 200, 429])
        finally:
            core._chat_llm, core.CHAT_RATE = orig, rate

    def test_7m_delete_and_purge_http(self):
        base = self.serve()
        core.log_activity("old", ts="2020-01-01 00:00:00"); core.log_activity("recent")
        rid, _ = core.save_report("activities")
        self.assertEqual(self.req(base, "/api/purge", {"days": 0})[0], 400)
        self.assertEqual(json.loads(self.req(base, "/api/purge", {"days": 1})[1])["deleted"]["activities"], 1)
        self.assertEqual(core.stats()["activities"]["total"], 1)
        self.assertEqual(self.req(base, "/api/saved/delete", {})[0], 400)
        self.assertEqual(json.loads(self.req(base, "/api/saved/delete", {"id": rid})[1])["deleted"], 1)
        self.assertIsNone(core.get_saved(rid))

    def test_7n_error_hooks(self):
        old = sys.excepthook, threading.excepthook; lg = logging.getLogger("jarvis_test"); h = core.JarvisLogHandler()
        lg.propagate = False; lg.addHandler(h)
        try:
            core.install_error_hook()  # the installed hook wraps (and still calls) the previous one
            with open(os.devnull, "w") as dn, contextlib.redirect_stderr(dn):
                sys.excepthook(ValueError, ValueError("boom"), None)
            lg.error("bad thing happened")
        finally:
            sys.excepthook, threading.excepthook = old; lg.removeHandler(h)
        errs = " | ".join(str(r["error"]) for r in core.query_activities(status="error"))
        self.assertIn("ValueError: boom", errs); self.assertIn("bad thing happened", errs)

    def test_8_never_raises(self):
        core.DB_PATH = "/nonexistent_dir/x.db"; core._ready = False
        self.assertFalse(core.log_activity("x")); self.assertFalse(core.upsert_task("x", "y"))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Jarvis reports dashboard")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--host", default="127.0.0.1", help="default 127.0.0.1 (this computer only); anything else needs a password")
    ap.add_argument("--demo", action="store_true", help="insert SAMPLE data for preview")
    ap.add_argument("--test", action="store_true", help="run built-in self-tests")
    ap.add_argument("--set-password", action="store_true", help="(optional) require a password")
    ap.add_argument("--remove-password", action="store_true", help="turn the password off again")
    a = ap.parse_args()
    if a.test:
        unittest.main(argv=[sys.argv[0]], verbosity=2)
    if a.remove_password:
        clear_password(); print("Password removed.")
    elif a.set_password:
        _prompt_password()
    if a.demo:
        seed_demo()
    start(host=a.host, port=a.port)
